from pathlib import Path


import os, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
from matplotlib.colors import TwoSlopeNorm
from scipy import stats
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import adfuller, kpss
import pywt

warnings.filterwarnings("ignore")
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "figure.dpi": 150,
})

DATA_DIR = Path(__file__).resolve().parent / "Dataset"
RESULTS_DIR = Path(__file__).resolve().parent / "Results05062026"
Path(RESULTS_DIR).mkdir(parents=True, exist_ok=True)

print("=" * 60)
print("STEP 1 — Loading and preparing data …")
print("=" * 60)

def load_etf(filename, price_col="Price"):
    """Load ETF price file, sort by date, return price series."""
    path = os.path.join(DATA_DIR, filename)
    df = pd.read_csv(path)

    df.columns = (df.columns.str.strip()
                              .str.replace('\ufeff', '', regex=False)
                              .str.replace('"', '', regex=False))
    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values("Date").reset_index(drop=True)

    df[price_col] = (df[price_col].astype(str)
                                   .str.replace(",", "", regex=False)
                                   .astype(float))
    return df.set_index("Date")[price_col]

robt_px  = load_etf("ROBT ETF Stock Price History.csv")
icln_px  = load_etf("ICLN ETF Stock Price History.csv")

gou_path = os.path.join(DATA_DIR, "Gold_Oil_USD.csv")
gou      = pd.read_csv(gou_path, parse_dates=["Date"]).set_index("Date").sort_index()

robt_ret = np.log(robt_px / robt_px.shift(1)).dropna() * 100
icln_ret = np.log(icln_px / icln_px.shift(1)).dropna() * 100

gou = gou * 100
gou.columns = ["Gold", "Oil", "USD"]

data = pd.concat([robt_ret.rename("Robotics"),
                  icln_ret.rename("CleanEnergy"),
                  gou], axis=1).dropna()

VARS   = list(data.columns)
N      = len(VARS)
T      = len(data)
print(f"\nVariables : {VARS}")
print(f"Period    : {data.index[0].date()}  →  {data.index[-1].date()}")
print(f"Obs       : {T}")

print("\n" + "=" * 60)
print("STEP 2 — Descriptive statistics …")
print("=" * 60)

def adf_pval(series):
    return adfuller(series.dropna(), autolag="AIC")[1]

def kpss_pval(series):
    try:
        return kpss(series.dropna(), regression="c", nlags="auto")[1]
    except:
        return np.nan

desc = data.describe().T
desc["Skewness"] = data.skew()
desc["Kurtosis"] = data.kurt()
desc["ADF_pval"] = [adf_pval(data[v]) for v in VARS]
desc["KPSS_pval"] = [kpss_pval(data[v]) for v in VARS]
desc = desc[["mean","std","min","max","Skewness","Kurtosis","ADF_pval","KPSS_pval"]]
desc.columns = ["Mean","Std","Min","Max","Skewness","Kurtosis","ADF p-val","KPSS p-val"]
desc.to_csv(os.path.join(RESULTS_DIR, "01_descriptive_stats.csv"))
print(desc.round(4).to_string())

fig, ax = plt.subplots(figsize=(7, 6))
corr = data.corr()
mask = np.zeros_like(corr, dtype=bool)
mask[np.triu_indices_from(mask, k=1)] = False
sns.heatmap(corr, annot=True, fmt=".2f", cmap="YlGn",
            vmin=-1, vmax=1, ax=ax, linewidths=0.5,
            annot_kws={"size": 11})
ax.set_title("Pearson Correlation Matrix", fontsize=14, fontweight="bold")
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "01_correlation_heatmap.png"), dpi=150)
plt.close()
print("\n✅  Descriptive stats saved.")

def compute_gfevd(B_list, Sigma, H=10):
    """
    Generalised Forecast Error Variance Decomposition.
    B_list : list of coefficient matrices [B1, B2, …, Bp]  each (N×N)
    Sigma  : residual covariance matrix (N×N)
    H      : forecast horizon
    Returns theta (N×N) where theta[i,j] = share of i's FEVD from j
    """
    n = Sigma.shape[0]

    p = len(B_list)
    Psi = [np.eye(n)]
    for h in range(1, H + 1):
        ph = np.zeros((n, n))
        for j in range(min(h, p)):
            ph += Psi[h - 1 - j] @ B_list[j]
        Psi.append(ph)

    sigma_diag = np.diag(Sigma)
    theta = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            num = sum((Psi[h][i, :] @ Sigma[:, j]) ** 2
                      for h in range(H + 1))
            den = sum(Psi[h][i, :] @ Sigma @ Psi[h][i, :]
                      for h in range(H + 1))
            theta[i, j] = (1.0 / sigma_diag[j]) * num / (den + 1e-12)

    row_sums = theta.sum(axis=1, keepdims=True)
    theta    = theta / (row_sums + 1e-12)
    return theta

def dy_metrics(theta):
    """FROM, TO, NET, TCI from a GFEVD matrix theta (row-normalised)."""
    n = theta.shape[0]
    frm = theta.sum(axis=1) - np.diag(theta)
    to  = theta.sum(axis=0) - np.diag(theta)
    net = to - frm
    tci = frm.sum() / n * 100
    return frm * 100, to * 100, net * 100, tci

print("\n" + "=" * 60)
print("STEP 3 — Static Diebold-Yilmaz …")
print("=" * 60)

model  = VAR(data.values)
res    = model.fit(maxlags=5, ic="aic")
p      = res.k_ar
B_list = [res.coefs[j] for j in range(p)]
Sigma  = res.sigma_u

theta_static = compute_gfevd(B_list, Sigma, H=10)
frm_s, to_s, net_s, tci_s = dy_metrics(theta_static)

print(f"\nStatic TCI = {tci_s:.2f}%")
dy_table = pd.DataFrame(theta_static * 100,
                         index=VARS, columns=VARS).round(2)
dy_table["FROM"] = frm_s.round(2)
dy_table.loc["TO"] = list(to_s.round(2)) + [np.nan]
dy_table.to_csv(os.path.join(RESULTS_DIR, "02_static_DY_table.csv"))

fig, ax = plt.subplots(figsize=(8, 6))
mat = theta_static * 100
sns.heatmap(mat, annot=True, fmt=".1f",
            cmap="RdYlGn_r", vmin=0, vmax=100,
            xticklabels=VARS, yticklabels=VARS, ax=ax,
            linewidths=0.4, annot_kws={"size": 11})
ax.set_title(f"Static DY Connectedness  (TCI = {tci_s:.1f}%)",
             fontweight="bold")
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "02_static_DY_heatmap.png"), dpi=150)
plt.close()

fig, axes = plt.subplots(1, 3, figsize=(14, 5))
for ax, vals, title, clr in zip(
        axes,
        [to_s, frm_s, net_s],
        ["TO Others", "FROM Others", "NET Spillover"],
        ["steelblue", "tomato", None]):
    colors = ([clr] * N if clr
              else ["seagreen" if v >= 0 else "tomato" for v in vals])
    ax.bar(VARS, vals, color=colors)
    ax.axhline(0, color="k", lw=0.8, ls="--")
    ax.set_title(title, fontweight="bold")
    ax.set_ylabel("Spillover (%)")
    ax.tick_params(axis="x", rotation=30)
fig.suptitle("Static DY Spillover Decomposition", fontweight="bold", fontsize=14)
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "02_static_DY_bars.png"), dpi=150)
plt.close()
print("✅  Static DY saved.")

print("\n" + "=" * 60)
print("STEP 4 — Rolling DY  (win=200) …  this takes a minute …")
print("=" * 60)

WIN   = 200
dates_roll = []
tci_roll   = []
net_roll   = {v: [] for v in VARS}
arr = data.values

for t in range(WIN, T):
    window = arr[t - WIN: t, :]
    try:
        m = VAR(window).fit(maxlags=4, ic="aic", trend="c")
        Bl = [m.coefs[j] for j in range(m.k_ar)]
        th = compute_gfevd(Bl, m.sigma_u, H=10)
        fr, to, nt, tc = dy_metrics(th)
        dates_roll.append(data.index[t])
        tci_roll.append(tc)
        for i, v in enumerate(VARS):
            net_roll[v].append(nt[i])
    except Exception:
        pass

roll_df = pd.DataFrame({"TCI": tci_roll}, index=dates_roll)
for v in VARS:
    roll_df[f"NET_{v}"] = net_roll[v]
roll_df.to_csv(os.path.join(RESULTS_DIR, "03_rolling_TCI.csv"))

fig, ax = plt.subplots(figsize=(13, 4))
ax.plot(roll_df.index, roll_df["TCI"], color="navy", lw=1.2)
ax.fill_between(roll_df.index, roll_df["TCI"], alpha=0.18, color="navy")
ax.set_title("Dynamic Total Connectedness Index — Rolling 200-Day Window",
             fontweight="bold")
ax.set_ylabel("TCI (%)")
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "03_rolling_TCI.png"), dpi=150)
plt.close()

COLORS = ["royalblue", "darkorange", "purple", "crimson", "saddlebrown"]
fig, axes = plt.subplots(N, 1, figsize=(13, 3.5 * N), sharex=True)
fig.suptitle("Net Pairwise Spillovers (Rolling)", fontweight="bold", fontsize=14)
for ax, v, c in zip(axes, VARS, COLORS):
    s = roll_df[f"NET_{v}"]
    ax.plot(roll_df.index, s, color=c, lw=1.0)
    ax.fill_between(roll_df.index, s, 0,
                    where=s >= 0, alpha=0.35, color="seagreen")
    ax.fill_between(roll_df.index, s, 0,
                    where=s < 0,  alpha=0.35, color="salmon")
    ax.axhline(0, color="k", lw=0.7, ls="--")
    ax.set_title(f"Net Spillover — {v}", fontsize=11, fontweight="bold")
    ax.set_ylabel("Net (%)")
    ax.grid(True, alpha=0.25)
axes[-1].xaxis.set_major_locator(mdates.YearLocator())
axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "03_rolling_NET_spillovers.png"), dpi=150)
plt.close()
print("✅  Rolling DY saved.")

print("\n" + "=" * 60)
print("STEP 5 — TVP-VAR  (λ=0.99) …  this takes a minute …")
print("=" * 60)

LAMBDA = 0.99

def tvp_var_step(X_lag, y, B_prev, Sigma_prev, lam):
    """
    One-step TVP-VAR update via exponential forgetting.
    X_lag  : (1 × k)  regressor row  [const, y_{t-1}, …]
    y      : (N,)     observation at t
    B_prev : (N × k)  coefficient matrix
    Sigma_prev : (N × N)  error covariance
    Returns B_new, Sigma_new, e (residual)
    """
    e        = y - (B_prev @ X_lag.T).flatten()
    Sigma_new = (1 / lam) * Sigma_prev + np.outer(e, e)
    B_new    = B_prev
    return B_new, Sigma_new, e

p_tvp  = 2
K      = N * p_tvp + 1

def build_X(arr_2d, t, p):
    """Return row vector [1, y_{t-1}, …, y_{t-p}]."""
    row = [1.0]
    for lag in range(1, p + 1):
        row.extend(arr_2d[t - lag])
    return np.array(row).reshape(1, -1)

init_end = 100
Yinit    = arr[p_tvp:init_end]
Xinit    = np.vstack([build_X(arr, t, p_tvp) for t in range(p_tvp, init_end)])

B0_T     = np.linalg.lstsq(Xinit, Yinit, rcond=None)[0]
B0       = B0_T.T
resid0   = Yinit - Xinit @ B0_T
Sigma0   = (resid0.T @ resid0) / (init_end - p_tvp - K)

tvp_dates = []
tvp_tci   = []
tvp_net   = {v: [] for v in VARS}

B_t     = B0.copy()
Sigma_t = Sigma0.copy()

for t in range(init_end, T):
    X_t = build_X(arr, t, p_tvp)
    y_t = arr[t]
    B_t, Sigma_t, _ = tvp_var_step(X_t, y_t, B_t, Sigma_t, LAMBDA)

    Bl = [B_t[:, 1 + i * N: 1 + (i + 1) * N] for i in range(p_tvp)]
    try:
        th = compute_gfevd(Bl, Sigma_t, H=10)
        fr, to, nt, tc = dy_metrics(th)
        tvp_dates.append(data.index[t])
        tvp_tci.append(tc)
        for i, v in enumerate(VARS):
            tvp_net[v].append(nt[i])
    except Exception:
        pass

tvp_df = pd.DataFrame({"TCI": tvp_tci}, index=tvp_dates)
for v in VARS:
    tvp_df[f"NET_{v}"] = tvp_net[v]
tvp_df.to_csv(os.path.join(RESULTS_DIR, "04_TVP_VAR_results.csv"))

fig, ax = plt.subplots(figsize=(13, 4))
ax.plot(tvp_df.index, tvp_df["TCI"], color="darkred", lw=1.2)
ax.fill_between(tvp_df.index, tvp_df["TCI"], alpha=0.18, color="darkred")
ax.set_title(r"TVP-VAR Total Connectedness Index  ($\lambda$=0.99)",
             fontweight="bold")
ax.set_ylabel("TCI (%)")
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "04_TVP_VAR_TCI.png"), dpi=150)
plt.close()

fig, axes = plt.subplots(N, 1, figsize=(13, 3.5 * N), sharex=True)
fig.suptitle("TVP-VAR Net Pairwise Spillovers", fontweight="bold", fontsize=14)
for ax, v, c in zip(axes, VARS, COLORS):
    s = tvp_df[f"NET_{v}"]
    ax.plot(tvp_df.index, s, color=c, lw=1.0)
    ax.fill_between(tvp_df.index, s, 0,
                    where=s >= 0, alpha=0.35, color="seagreen")
    ax.fill_between(tvp_df.index, s, 0,
                    where=s < 0,  alpha=0.35, color="salmon")
    ax.axhline(0, color="k", lw=0.7, ls="--")
    ax.set_title(f"TVP-VAR Net — {v}", fontsize=11, fontweight="bold")
    ax.set_ylabel("Net (%)")
    ax.grid(True, alpha=0.25)
axes[-1].xaxis.set_major_locator(mdates.YearLocator())
axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "04_TVP_VAR_NET.png"), dpi=150)
plt.close()
print("✅  TVP-VAR saved.")

print("\n" + "=" * 60)
print("STEP 6 — QVAR …")
print("=" * 60)

from statsmodels.regression.quantile_regression import QuantReg

QUANTILES = [0.05, 0.25, 0.50, 0.75, 0.95]
qvar_summary = []

def quantile_var_gfevd(data_arr, p, tau, H=10):
    """
    Estimate a quantile VAR equation-by-equation at quantile tau,
    then compute GFEVD using the quantile residual covariance.
    """
    n      = data_arr.shape[1]
    T_loc  = data_arr.shape[0]

    Y = data_arr[p:]
    X = np.hstack([np.ones((T_loc - p, 1))] +
                  [data_arr[p - lag: T_loc - lag]
                   for lag in range(1, p + 1)])
    B_q   = np.zeros((n, X.shape[1]))
    resid = np.zeros((T_loc - p, n))

    for i in range(n):
        qr = QuantReg(Y[:, i], X).fit(q=tau, max_iter=2000)
        B_q[i, :] = qr.params
        resid[:, i] = qr.resid

    Sigma_q = (resid.T @ resid) / (T_loc - p)
    Bl = [B_q[:, 1 + j * n: 1 + (j + 1) * n] for j in range(p)]
    th = compute_gfevd(Bl, Sigma_q, H=H)
    return th

qvar_rows = []
for tau in QUANTILES:
    print(f"   τ = {tau} …", end=" ", flush=True)
    try:
        th_q = quantile_var_gfevd(data.values, p=2, tau=tau, H=10)
        fr_q, to_q, nt_q, tc_q = dy_metrics(th_q)
        row = {"tau": tau, "TCI": round(tc_q, 4)}
        for i, v in enumerate(VARS):
            row[f"NET_{v}"]  = round(nt_q[i], 4)
            row[f"TO_{v}"]   = round(to_q[i], 4)
            row[f"FROM_{v}"] = round(fr_q[i], 4)
        qvar_rows.append(row)
        print(f"TCI={tc_q:.2f}%")
    except Exception as ex:
        print(f"Error: {ex}")

qvar_df = pd.DataFrame(qvar_rows)
qvar_df.to_csv(os.path.join(RESULTS_DIR, "05_QVAR_summary.csv"), index=False)

fig, ax = plt.subplots(figsize=(7, 5))
ax.plot(qvar_df["tau"], qvar_df["TCI"], "o-", color="purple",
        lw=2, ms=8, zorder=5)
ax.axhline(tci_s, color="k", ls="--", lw=1.2,
           label=f"Static DY ({tci_s:.1f}%)")
ax.set_xlabel("Quantile (τ)")
ax.set_ylabel("Total Connectedness Index (%)")
ax.set_title("QVAR — Total Connectedness Across Quantiles", fontweight="bold")
ax.legend()
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "05_QVAR_TCI_across_quantiles.png"), dpi=150)
plt.close()

bar_w   = 0.15
x_pos   = np.arange(len(QUANTILES))
fig, ax = plt.subplots(figsize=(13, 6))
bar_colors = COLORS
for i, v in enumerate(VARS):
    net_vals = [row[f"NET_{v}"] for row in qvar_rows]
    ax.bar(x_pos + i * bar_w, net_vals, bar_w,
           label=v, color=bar_colors[i], alpha=0.85)
ax.axhline(0, color="k", lw=0.9)
ax.set_xticks(x_pos + bar_w * (N - 1) / 2)
ax.set_xticklabels([f"τ={q}" for q in QUANTILES])
ax.set_ylabel("Net Spillover (%)")
ax.set_title("QVAR — Net Spillovers Across Quantiles", fontweight="bold")
ax.legend(ncol=N, fontsize=9)
ax.grid(True, alpha=0.25, axis="y")
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "05_QVAR_NET_bars.png"), dpi=150)
plt.close()
print("✅  QVAR saved.")

print("\n" + "=" * 60)
print("STEP 7 — Quantile-on-Quantile (Cross-Quantilogram) …")
print("=" * 60)

QQ_LEVELS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

def cross_quantilogram(x, y, tau_x, tau_y, lag=1):
    """
    Cross-quantilogram of Linton & Whang (2007).
    Measures P( y_t ≤ Q_y(τ_y) | x_{t-lag} ≤ Q_x(τ_x) ) minus τ_y.
    Returns the normalised statistic (Spearman-like scalar in [-1,1]).
    """
    qx = np.quantile(x, tau_x)
    qy = np.quantile(y, tau_y)
    hit_x = (x[:-lag] <= qx).astype(float) - tau_x
    hit_y = (y[lag:]  <= qy).astype(float) - tau_y
    num = np.mean(hit_x * hit_y)
    den = np.sqrt(tau_x * (1 - tau_x) * tau_y * (1 - tau_y)) + 1e-12
    return num / den

pairs    = [(v1, v2) for i, v1 in enumerate(VARS)
                     for j, v2 in enumerate(VARS) if i != j]
qq_mean  = pd.DataFrame(np.zeros((N, N)), index=VARS, columns=VARS)

n_pairs   = len(pairs)
n_col_fig = 3
n_row_fig = (n_pairs + n_col_fig - 1) // n_col_fig
fig_qq, axes_qq = plt.subplots(n_row_fig, n_col_fig,
                                figsize=(5 * n_col_fig, 4.5 * n_row_fig))
axes_qq = axes_qq.flatten()

for idx, (v1, v2) in enumerate(pairs):
    mat = np.zeros((len(QQ_LEVELS), len(QQ_LEVELS)))
    for ri, tx in enumerate(QQ_LEVELS):
        for ci, ty in enumerate(QQ_LEVELS):
            mat[ri, ci] = cross_quantilogram(
                data[v1].values, data[v2].values, tx, ty, lag=1)
    qq_mean.loc[v2, v1] = float(np.mean(np.abs(mat)))

    ax = axes_qq[idx]
    norm = TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)
    im = ax.imshow(mat, cmap="RdBu_r", norm=norm, aspect="auto",
                   origin="lower")
    tl = [f"{q:.1f}" for q in QQ_LEVELS]
    ax.set_xticks(range(len(QQ_LEVELS))); ax.set_xticklabels(tl, fontsize=7)
    ax.set_yticks(range(len(QQ_LEVELS))); ax.set_yticklabels(tl, fontsize=7)
    ax.set_xlabel(f"τ({v2})", fontsize=8)
    ax.set_ylabel(f"τ({v1})", fontsize=8)
    ax.set_title(f"{v1} → {v2}", fontsize=9, fontweight="bold")
    fig_qq.colorbar(im, ax=ax, fraction=0.04)

for ax in axes_qq[len(pairs):]:
    ax.set_visible(False)

fig_qq.suptitle("Quantile-on-Quantile Cross-Quantilogram (lag=1)",
                fontweight="bold", fontsize=13)
plt.tight_layout()
fig_qq.savefig(os.path.join(RESULTS_DIR, "06_QQ_heatmaps.png"), dpi=130)
plt.close()

fig, ax = plt.subplots(figsize=(7, 6))
temp = qq_mean.values.copy()
np.fill_diagonal(temp, 0)
qq_mean[:] = temp
sns.heatmap(qq_mean, annot=True, fmt=".3f",
            cmap="YlOrRd", vmin=0, vmax=0.4,
            ax=ax, linewidths=0.5, annot_kws={"size": 11})
ax.set_title("Mean |Cross-Quantilogram| — QQ Connectedness Summary",
             fontweight="bold")
plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "06_QQ_summary_heatmap.png"), dpi=150)
plt.close()

qq_mean.to_csv(os.path.join(RESULTS_DIR, "06_QQ_mean_connectedness.csv"))
print("✅  QQ Cross-Quantilogram saved.")

print("\n" + "=" * 60)
print("STEP 8 — Wavelet analysis …")
print("=" * 60)

W_QUANTILES = [0.10, 0.25, 0.50, 0.75, 0.90]
WAVELET     = "db4"
LEVEL       = 5

def dwt_quantile_corr(x, y, wavelet=WAVELET, level=LEVEL, quantiles=W_QUANTILES):
    """
    DWT decomposition + Spearman rank correlation at each
    wavelet scale and quantile.
    """
    coeffs_x = pywt.wavedec(x, wavelet, level=level)
    coeffs_y = pywt.wavedec(y, wavelet, level=level)
    scale_names = [f"d{level - i}" for i in range(level)] + ["Approx"]
    results = {}
    for sc, (cx, cy) in zip(scale_names,
                             zip(coeffs_x[::-1], coeffs_y[::-1])):
        min_len = min(len(cx), len(cy))
        cx, cy  = cx[:min_len], cy[:min_len]
        q_corrs = []
        for tau in quantiles:
            qx = np.quantile(cx, [tau - 0.05, tau + 0.05])
            qy = np.quantile(cy, [tau - 0.05, tau + 0.05])
            mask = ((cx >= qx[0]) & (cx <= qx[1]) &
                    (cy >= qy[0]) & (cy <= qy[1]))
            if mask.sum() > 5:
                rho, _ = stats.spearmanr(cx[mask], cy[mask])
            else:
                rho = stats.spearmanr(cx, cy)[0]
            q_corrs.append(rho)
        results[sc] = q_corrs
    return results, scale_names

wq_pairs = [(v1, v2) for i, v1 in enumerate(VARS)
                     for j, v2 in enumerate(VARS) if i < j]

n_wp      = len(wq_pairs)
n_col_wq  = 3
n_row_wq  = (n_wp + n_col_wq - 1) // n_col_wq
fig_wq, axes_wq = plt.subplots(n_row_wq, n_col_wq,
                                figsize=(6 * n_col_wq, 4.5 * n_row_wq))
axes_wq = axes_wq.flatten()
WQ_COLORS = ["navy","dodgerblue","seagreen","darkorange","crimson"]
wq_all = {}

for idx, (v1, v2) in enumerate(wq_pairs):
    res, scnames = dwt_quantile_corr(data[v1].values.copy(), data[v2].values.copy())
    wq_all[f"{v1}_{v2}"] = res
    ax = axes_wq[idx]
    for qi, (tau, col) in enumerate(zip(W_QUANTILES, WQ_COLORS)):
        vals = [res[sc][qi] for sc in scnames]
        ax.plot(scnames, vals, "o-", color=col, lw=1.4,
                label=f"τ={tau}", ms=5)
    ax.axhline(0, color="k", lw=0.7, ls="--")
    ax.set_ylim(-1.05, 1.05)
    ax.set_title(f"WQC: {v1} vs {v2}", fontsize=9, fontweight="bold")
    ax.set_xlabel("Scale")
    ax.set_ylabel("Spearman ρ")
    ax.legend(fontsize=6, ncol=3)
    ax.grid(True, alpha=0.25)

for ax in axes_wq[n_wp:]:
    ax.set_visible(False)

fig_wq.suptitle(f"Wavelet Quantile Correlation (DWT: {WAVELET}, L={LEVEL})",
                fontweight="bold", fontsize=13)
plt.tight_layout()
fig_wq.savefig(os.path.join(RESULTS_DIR, "08_wavelet_quantile_correlation.png"),
               dpi=130)
plt.close()

rows_wq = []
for pair, res in wq_all.items():
    for sc, vals in res.items():
        for tau, rho in zip(W_QUANTILES, vals):
            rows_wq.append({"pair": pair, "scale": sc,
                            "quantile": tau, "spearman_rho": round(rho, 4)})
pd.DataFrame(rows_wq).to_csv(
    os.path.join(RESULTS_DIR, "08_wavelet_quantile_corr.csv"), index=False)

def morlet_coherence(x, y, scales=None):
    """
    Approximate Morlet wavelet coherence using CWT magnitudes.
    Returns (time×scale) coherence matrix.
    """
    if scales is None:
        scales = np.arange(1, 129)
    wx, _  = pywt.cwt(x, scales, "morl")
    wy, _  = pywt.cwt(y, scales, "morl")
    Sxy    = np.abs(wx * np.conj(wy))
    Sxx    = np.abs(wx) ** 2
    Syy    = np.abs(wy) ** 2
    coh    = Sxy / (np.sqrt(Sxx * Syy) + 1e-12)
    return coh, scales

coh_pairs = wq_pairs
n_cp   = len(coh_pairs)
n_cc   = 2
n_rc   = (n_cp + n_cc - 1) // n_cc
fig_c, axes_c = plt.subplots(n_rc, n_cc,
                              figsize=(10 * n_cc, 4 * n_rc))
axes_c = axes_c.flatten()
scales_morlet = np.arange(1, 65)

for idx, (v1, v2) in enumerate(coh_pairs):
    coh, scs = morlet_coherence(data[v1].values, data[v2].values,
                                scales=scales_morlet)
    log_coh = np.log2(coh + 1e-8)
    ax = axes_c[idx]
    im = ax.imshow(log_coh, aspect="auto", cmap="RdYlBu_r",
                   origin="lower",
                   extent=[0, T, scs[-1], scs[0]],
                   vmin=-8, vmax=0)
    ax.set_title(f"Coherence: {v1} vs {v2}", fontsize=9, fontweight="bold")
    ax.set_xlabel("Time (obs)")
    ax.set_ylabel("Period (days)")
    fig_c.colorbar(im, ax=ax, label="log₂(Coherence)", fraction=0.03)

for ax in axes_c[n_cp:]:
    ax.set_visible(False)

fig_c.suptitle("Wavelet (Morlet) Coherence Analysis",
               fontweight="bold", fontsize=13)
plt.tight_layout()
fig_c.savefig(os.path.join(RESULTS_DIR, "07_wavelet_coherence.png"), dpi=130)
plt.close()
print("✅  Wavelet analysis saved.")

print("\n" + "=" * 60)
print("STEP 9 — Summary dashboard …")
print("=" * 60)

fig = plt.figure(figsize=(16, 12))
fig.suptitle(
    "Connectedness Analysis — Summary Dashboard\n"
    f"Variables: {', '.join(VARS)}  |  Period: "
    f"{data.index[0].strftime('%b %Y')} – {data.index[-1].strftime('%b %Y')}",
    fontsize=13, fontweight="bold")

ax1 = fig.add_subplot(2, 2, (1, 2))
ax1.plot(roll_df.index, roll_df["TCI"],
         color="navy", lw=1.3, label="Rolling DY (win=200d)")
ax1.plot(tvp_df.index, tvp_df["TCI"],
         color="darkred", lw=1.3, ls="--", label=r"TVP-VAR ($\lambda$=0.99)")
ax1.set_title("Dynamic Total Connectedness Index Comparison", fontweight="bold")
ax1.set_ylabel("TCI (%)")
ax1.legend()
ax1.xaxis.set_major_locator(mdates.YearLocator())
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax1.grid(True, alpha=0.25)

ax2 = fig.add_subplot(2, 2, 3)
ax2.plot(qvar_df["tau"], qvar_df["TCI"], "o-",
         color="purple", lw=2, ms=8)
ax2.axhline(tci_s, color="k", ls="--", lw=1.2,
            label=f"Static DY ({tci_s:.1f}%)")
ax2.set_xlabel("Quantile (τ)"); ax2.set_ylabel("TCI (%)")
ax2.set_title("QVAR: TCI Across Quantiles", fontweight="bold")
ax2.legend(fontsize=9)
ax2.grid(True, alpha=0.3)

ax3 = fig.add_subplot(2, 2, 4)
clrs = ["seagreen" if v >= 0 else "tomato" for v in net_s]
ax3.bar(VARS, net_s, color=clrs)
ax3.axhline(0, color="k", lw=0.8, ls="--")
ax3.set_ylabel("Net Spillover (%)")
ax3.set_title("Static DY: Net Spillovers", fontweight="bold")
ax3.tick_params(axis="x", rotation=30)

plt.tight_layout()
fig.savefig(os.path.join(RESULTS_DIR, "00_summary_dashboard.png"), dpi=150)
plt.close()
print("✅  Summary dashboard saved.")

print("\n" + "=" * 60)
print("ALL DONE — Results saved to:")
print(f"  {RESULTS_DIR}")
print("=" * 60)

saved_files = sorted(os.listdir(RESULTS_DIR))
print(f"\nFiles generated ({len(saved_files)}):")
for f in saved_files:
    print(f"  ✅  {f}")