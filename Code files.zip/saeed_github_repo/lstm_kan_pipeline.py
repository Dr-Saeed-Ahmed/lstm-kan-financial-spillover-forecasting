import numpy as np
from scipy import stats

def diebold_mariano(e1, e2, h=1):
    """Harvey-Leybourne-Newbold corrected DM test.
    e1, e2: forecast error arrays (predicted - actual) for model1 and model2.
    Returns (DM statistic, two-sided p-value). Negative DM favours model2.
    """
    d = e1**2 - e2**2
    T = len(d)
    dbar = np.mean(d)

    gamma0 = np.var(d, ddof=0)
    gamma = [np.cov(d[k:], d[:-k])[0,1] if k > 0 else 0 for k in range(1, h)]
    var_d = (gamma0 + 2 * sum(gamma)) / T
    DM = dbar / np.sqrt(var_d)

    k = (T + 1 - 2*h + h*(h-1)/T) / T
    DM_adj = DM * np.sqrt(k)
    p = 2 * stats.t.sf(abs(DM_adj), df=T-1)
    return DM_adj, p

