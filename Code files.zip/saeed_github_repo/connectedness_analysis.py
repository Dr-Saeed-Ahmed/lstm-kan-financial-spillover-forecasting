"""
=============================================================================
  CONNECTEDNESS ANALYSIS SUITE — THESIS
  Models : Static DY | Rolling DY | TVP-VAR | QVAR | QQ | Wavelet
  Data   : Returns_Data.csv  &  GARCH11_Volatility_Data.csv
  Author : [Your Name]
=============================================================================
Requirements (install once via pip):
    pip install numpy pandas matplotlib seaborn statsmodels scipy PyWavelets arch
=============================================================================
"""

from pathlib import Path

import os
import sys
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from scipy import linalg, stats
from scipy.signal import coherence

from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.regression.quantile_regression import QuantReg
from statsmodels.stats.diagnostic import acorr_ljungbox

import pywt

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import matplotlib.ticker as mticker
from matplotlib.colors import LinearSegmentedColormap
import seaborn as sns

plt.rcParams.update({
    "font.family": "serif",
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "figure.dpi": 150,
})

BASE_PATH = Path(__file__).resolve().parent / "Dataset"
RETURNS_FILE   = os.path.join(BASE_PATH, "Returns_Data.csv")
VOLATIL_FILE   = os.path.join(BASE_PATH, "GARCH11_Volatility_Data.csv")
OUTPUT_PATH    = os.path.join(BASE_PATH, "Results")
os.makedirs(OUTPUT_PATH, exist_ok=True)

SELECTED_VARS = ["THNQ", "ROBT", "ICLN", "WTI", "GLD", "USD"]

USE_VOLATILITY = False

VAR_LAGS        = 2
FORECAST_H      = 10
ROLLING_WIN     = 200
TVP_FORGETTING  = 0.99
QUANTILES_QVAR  = [0.05, 0.25, 0.50, 0.75, 0.95]
QQ_TAU          = np.round(np.arange(0.1, 1.0, 0.1), 1)
WAVELET_NAME    = "cmor1.5-1.0"
WAVELET_DWT     = "db4"
DWT_LEVELS      = 5

LABEL_MAP = {
    "THNQ": "AI-THNQ",  "ROBT": "Robotics",   "SRVR": "DataCentre",
    "REMX": "RareEarth", "NCLR": "Nuclear",     "ICLN": "CleanEnergy",
    "GRNB": "GreenBond", "SUSA": "ESG-US",      "CRBN": "LowCarbon",
    "DSI":  "SocialETF", "WTI":  "Oil",          "GLD":  "Gold",
    "USD":  "USD",
}

COLORS = ["#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd",
          "#8c564b","#e377c2","#7f7f7f","#bcbd22","#17becf",
          "#aec7e8","#ffbb78","#98df8a"]

LABELS = [LABEL_MAP.get(v, v) for v in SELECTED_VARS]
N      = len(SELECTED_VARS)

print("=" * 70)
print("  CONNECTEDNESS ANALYSIS SUITE")
print("=" * 70)

def load_data(path: str, cols: list, use_vol: bool) -> pd.DataFrame:
    """Load returns or volatility data and subset to selected variables."""
    if use_vol:
        df = pd.read_csv(VOLATIL_FILE, parse_dates=["Date"], index_col="Date")
        print(f"[INFO] Using GARCH(1,1) volatility from: {VOLATIL_FILE}")
    else:
        df = pd.read_csv(RETURNS_FILE, parse_dates=["Date"], index_col="Date")
        print(f"[INFO] Using daily returns from: {RETURNS_FILE}")

    missing = [c for c in cols if c not in df.columns]
    if missing:
        sys.exit(f"[ERROR] Variables not found in dataset: {missing}\n"
                 f"        Available: {list(df.columns)}")
    df = df[cols].dropna()
    print(f"[INFO] Variables selected : {cols}")
    print(f"[INFO] Date range         : {df.index[0].date()} → {df.index[-1].date()}")
    print(f"[INFO] Observations       : {len(df)}")
    return df

data = load_data(BASE_PATH, SELECTED_VARS, USE_VOLATILITY)
Y    = data.values
T, N = Y.shape
dates = data.index

print("\n" + "─" * 70)
print("  DESCRIPTIVE STATISTICS")
print("─" * 70)

desc = data.describe().T
desc["skewness"] = data.skew()
desc["kurtosis"] = data.kurtosis()

adf_pvals, kpss_pvals = [], []
for col in SELECTED_VARS:
    adf_pvals.append(adfuller(data[col], autolag="AIC")[1])
    kpss_pvals.append(kpss(data[col], regression="c", nlags="auto")[1])

desc["ADF p-val"]  = adf_pvals
desc["KPSS p-val"] = kpss_pvals
print(desc[["mean","std","min","max","skewness","kurtosis","ADF p-val","KPSS p-val"]].round(4).to_string())

desc_path = os.path.join(OUTPUT_PATH, "01_descriptive_stats.csv")
desc.round(4).to_csv(desc_path)
print(f"\n[SAVED] {desc_path}")

fig, ax = plt.subplots(figsize=(8, 6))
corr = data.corr()
corr.index = LABELS; corr.columns = LABELS
sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdYlGn",
            center=0, linewidths=0.5, ax=ax, annot_kws={"size": 8})
ax.set_title("Pearson Correlation Matrix", fontweight="bold")
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "01_correlation_heatmap.png"), dpi=150)
plt.close()
print("[SAVED] 01_correlation_heatmap.png")

def _var_companion(A_list: list, n: int) -> np.ndarray:
    """Build companion matrix from list of coefficient matrices [A1,…,Ap]."""
    p   = len(A_list)
    C   = np.zeros((n * p, n * p))
    for i, Ai in enumerate(A_list):
        C[:n, i * n:(i + 1) * n] = Ai
    if p > 1:
        C[n:, :-n] = np.eye(n * (p - 1))
    return C

def gfevd(A_list: list, Sigma: np.ndarray, H: int) -> np.ndarray:
    """
    Generalised Forecast Error Variance Decomposition (Koop et al., 1996;
    Pesaran & Shin, 1998).  Returns N×N share matrix (rows = receiving,
    cols = sending).
    """
    n  = Sigma.shape[0]
    p  = len(A_list)
    sd = np.sqrt(np.diag(Sigma))

    C   = _var_companion(A_list, n)
    Psi = np.zeros((H + 1, n, n))
    Psi[0] = np.eye(n)
    Cp = np.eye(n * p)
    for h in range(1, H + 1):
        Cp = Cp @ C
        Psi[h] = Cp[:n, :n]

    GFEVD = np.zeros((n, n))
    for j in range(n):
        ej = np.zeros(n); ej[j] = 1.0
        denom = np.sum([Psi[h] @ Sigma @ Psi[h].T for h in range(H + 1)],
                       axis=0)[j, j]
        for i in range(n):
            ei    = np.zeros(n); ei[i] = 1.0
            numer = np.sum([(ei @ Psi[h] @ Sigma @ ej) ** 2
                            for h in range(H + 1)])
            GFEVD[j, i] = numer / (Sigma[i, i] * denom)

    GFEVD = GFEVD / GFEVD.sum(axis=1, keepdims=True)
    return GFEVD

def connectedness_table(GFEVD_mat: np.ndarray,
                        labels: list) -> dict:
    """
    From a normalised GFEVD matrix compute the full DY connectedness table.
    Returns a dict with FROM, TO, NET, TOTAL.
    """
    n   = GFEVD_mat.shape[0]
    own = np.diag(GFEVD_mat)

    FROM  = 1 - own
    TO    = (GFEVD_mat.sum(axis=0) - own)
    NET   = TO - FROM
    TOTAL = FROM.mean()

    df = pd.DataFrame(GFEVD_mat * 100, index=labels, columns=labels).round(2)
    df["FROM"] = (FROM * 100).round(2)
    row_to     = pd.Series(np.append(TO * 100, TOTAL * 100),
                           index=labels + ["TCI"])
    df.loc["TO"] = row_to
    df.loc["NET"] = pd.Series(np.append(NET * 100,
                                         np.nan), index=labels + ["TCI"])
    return {"table": df, "FROM": FROM, "TO": TO, "NET": NET,
            "TCI": TOTAL, "matrix": GFEVD_mat}

def fit_var(Y_: np.ndarray, lags: int):
    """Fit a VAR(p) model and return coefficient list + residual covariance."""
    model  = VAR(Y_)
    result = model.fit(lags, trend="c")
    A_list = [result.coefs[i] for i in range(lags)]
    Sigma  = result.sigma_u
    return A_list, Sigma, result

def plot_connectedness_table(ct: dict, title: str, fname: str):
    """Save a colour-coded connectedness heatmap."""
    tbl = ct["table"].copy().drop(index=["TO", "NET"])
    tbl = tbl.drop(columns=["FROM"])
    mat = tbl.values.astype(float)

    fig, ax = plt.subplots(figsize=(max(7, N + 2), max(5, N + 1)))
    im = ax.imshow(mat, cmap="YlOrRd", aspect="auto")
    ax.set_xticks(range(len(tbl.columns)))
    ax.set_yticks(range(len(tbl.index)))
    ax.set_xticklabels(tbl.columns, rotation=45, ha="right")
    ax.set_yticklabels(tbl.index)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax.text(j, i, f"{mat[i, j]:.1f}", ha="center", va="center",
                    fontsize=7, color="black")
    plt.colorbar(im, ax=ax, fraction=0.03)
    ax.set_title(title, fontweight="bold")
    plt.tight_layout()
    fig.savefig(os.path.join(OUTPUT_PATH, fname), dpi=150)
    plt.close()

print("\n" + "─" * 70)
print("  MODEL 1 — STATIC DY CONNECTEDNESS (Diebold & Yilmaz, 2012)")
print("─" * 70)

A_static, Sigma_static, var_static = fit_var(Y, VAR_LAGS)
GFEVD_static = gfevd(A_static, Sigma_static, FORECAST_H)
CT_static     = connectedness_table(GFEVD_static, LABELS)

print(f"\n  Total Connectedness Index (TCI) = {CT_static['TCI']*100:.2f}%\n")
print(CT_static["table"].to_string())

ct_path = os.path.join(OUTPUT_PATH, "02_static_DY_table.csv")
CT_static["table"].to_csv(ct_path)
print(f"\n[SAVED] {ct_path}")

plot_connectedness_table(CT_static,
    f"Static DY Connectedness (TCI = {CT_static['TCI']*100:.1f}%)",
    "02_static_DY_heatmap.png")
print("[SAVED] 02_static_DY_heatmap.png")

fig, axes = plt.subplots(1, 3, figsize=(14, 4), sharey=False)
for ax, series, title, color in zip(
        axes,
        [CT_static["TO"]*100, CT_static["FROM"]*100, CT_static["NET"]*100],
        ["TO Others", "FROM Others", "NET Spillover"],
        ["steelblue", "tomato", "seagreen"]):
    ax.bar(LABELS, series, color=color, edgecolor="white", linewidth=0.8)
    ax.axhline(0, color="k", linewidth=0.7, linestyle="--")
    ax.set_title(title, fontweight="bold")
    ax.set_xticklabels(LABELS, rotation=45, ha="right")
    ax.set_ylabel("Spillover (%)")
fig.suptitle("Static DY Spillover Decomposition", fontweight="bold", y=1.02)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "02_static_DY_bars.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 02_static_DY_bars.png")

print("\n" + "─" * 70)
print(f"  MODEL 2 — ROLLING DY CONNECTEDNESS (window = {ROLLING_WIN} days)")
print("─" * 70)

TCI_rolling  = []
TO_rolling   = np.zeros((T - ROLLING_WIN, N))
FROM_rolling = np.zeros((T - ROLLING_WIN, N))
NET_rolling  = np.zeros((T - ROLLING_WIN, N))
roll_dates   = []

for t in range(T - ROLLING_WIN):
    Y_win = Y[t: t + ROLLING_WIN]
    try:
        A_t, S_t, _ = fit_var(Y_win, VAR_LAGS)
        G_t  = gfevd(A_t, S_t, FORECAST_H)
        ct_t = connectedness_table(G_t, LABELS)
        TCI_rolling.append(ct_t["TCI"] * 100)
        TO_rolling[t]   = ct_t["TO"]   * 100
        FROM_rolling[t] = ct_t["FROM"] * 100
        NET_rolling[t]  = ct_t["NET"]  * 100
    except Exception:
        TCI_rolling.append(np.nan)
    roll_dates.append(dates[t + ROLLING_WIN])

roll_dates = pd.DatetimeIndex(roll_dates)
print(f"  Rolling estimation complete. "
      f"Mean TCI = {np.nanmean(TCI_rolling):.2f}%")

fig, ax = plt.subplots(figsize=(13, 4))
ax.plot(roll_dates, TCI_rolling, color="navy", linewidth=1.2)
ax.fill_between(roll_dates, TCI_rolling, alpha=0.15, color="navy")
ax.set_title(f"Dynamic Total Connectedness Index — Rolling {ROLLING_WIN}-Day Window",
             fontweight="bold")
ax.set_ylabel("TCI (%)")
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "03_rolling_TCI.png"), dpi=150)
plt.close()
print("[SAVED] 03_rolling_TCI.png")

fig, axes = plt.subplots(N, 1, figsize=(13, 2.5 * N), sharex=True)
for i, ax in enumerate(axes):
    ax.plot(roll_dates, NET_rolling[:, i], color=COLORS[i], linewidth=1)
    ax.axhline(0, color="k", linewidth=0.6, linestyle="--")
    ax.fill_between(roll_dates, NET_rolling[:, i], 0,
                    where=NET_rolling[:, i] > 0, alpha=0.25, color="green")
    ax.fill_between(roll_dates, NET_rolling[:, i], 0,
                    where=NET_rolling[:, i] < 0, alpha=0.25, color="red")
    ax.set_title(f"Net Spillover — {LABELS[i]}", fontweight="bold", fontsize=10)
    ax.grid(True, alpha=0.3)
axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
axes[-1].xaxis.set_major_locator(mdates.YearLocator())
plt.suptitle("Net Pairwise Spillovers (Rolling)", fontweight="bold", y=1.01)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "03_rolling_NET_spillovers.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 03_rolling_NET_spillovers.png")

pd.DataFrame({"Date": roll_dates, "TCI": TCI_rolling}).to_csv(
    os.path.join(OUTPUT_PATH, "03_rolling_TCI.csv"), index=False)

print("\n" + "─" * 70)
print(f"  MODEL 3 — TVP-VAR CONNECTEDNESS (λ = {TVP_FORGETTING})")
print("─" * 70)

def tvp_var_connectedness(Y_: np.ndarray, p: int, lam: float, H: int,
                           burn_in: int = 50):
    """
    Time-varying VAR via forgetting-factor Kalman filter.
    Returns arrays: TCI[T-p], TO[T-p, N], FROM[T-p, N], NET[T-p, N].
    """
    T_, n   = Y_.shape
    k       = n * p + 1
    K       = n * k

    theta   = np.zeros(K)
    P       = 10 * np.eye(K)

    TCI_  = np.full(T_ - p, np.nan)
    TO_   = np.full((T_ - p, n), np.nan)
    FROM_ = np.full((T_ - p, n), np.nan)
    NET_  = np.full((T_ - p, n), np.nan)

    Sigma_hat = np.eye(n)

    for t in range(p, T_):
        idx = t - p

        x_t = np.hstack([Y_[t - i] for i in range(1, p + 1)] + [1.0])

        X_t = np.kron(np.eye(n), x_t.reshape(1, -1))

        P_pred = P / lam

        y_hat  = X_t @ theta
        e_t    = Y_[t] - y_hat
        F_t    = X_t @ P_pred @ X_t.T + Sigma_hat
        K_gain = P_pred @ X_t.T @ np.linalg.inv(F_t)
        theta  = theta + K_gain @ e_t
        P      = P_pred - K_gain @ X_t @ P_pred

        Sigma_hat = lam * Sigma_hat + (1 - lam) * np.outer(e_t, e_t)

        if t < p + burn_in:
            continue

        B = theta.reshape(n, k)
        A_list_t = [B[:, i * n:(i + 1) * n] for i in range(p)]

        try:
            G_t  = gfevd(A_list_t, Sigma_hat, H)
            ct_t = connectedness_table(G_t, LABELS)
            TCI_[idx]  = ct_t["TCI"] * 100
            TO_[idx]   = ct_t["TO"]   * 100
            FROM_[idx] = ct_t["FROM"] * 100
            NET_[idx]  = ct_t["NET"]  * 100
        except Exception:
            pass

    return TCI_, TO_, FROM_, NET_

BURN = 50
TCI_tvp, TO_tvp, FROM_tvp, NET_tvp = tvp_var_connectedness(
    Y, VAR_LAGS, TVP_FORGETTING, FORECAST_H, BURN)

tvp_dates = dates[VAR_LAGS:]
valid     = ~np.isnan(TCI_tvp)
print(f"  TVP-VAR complete. Mean TCI = {np.nanmean(TCI_tvp):.2f}%")

fig, ax = plt.subplots(figsize=(13, 4))
ax.plot(tvp_dates[valid], TCI_tvp[valid], color="darkred", linewidth=1.2)
ax.fill_between(tvp_dates[valid], TCI_tvp[valid], alpha=0.15, color="darkred")
ax.set_title(f"TVP-VAR Total Connectedness Index  (λ={TVP_FORGETTING})",
             fontweight="bold")
ax.set_ylabel("TCI (%)")
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "04_TVP_VAR_TCI.png"), dpi=150)
plt.close()
print("[SAVED] 04_TVP_VAR_TCI.png")

fig, axes = plt.subplots(N, 1, figsize=(13, 2.5 * N), sharex=True)
for i, ax in enumerate(axes):
    net_i = NET_tvp[valid, i]
    d_i   = tvp_dates[valid]
    ax.plot(d_i, net_i, color=COLORS[i], linewidth=1)
    ax.axhline(0, color="k", linewidth=0.6, linestyle="--")
    ax.fill_between(d_i, net_i, 0, where=net_i > 0,
                    alpha=0.25, color="green")
    ax.fill_between(d_i, net_i, 0, where=net_i < 0,
                    alpha=0.25, color="red")
    ax.set_title(f"TVP-VAR Net — {LABELS[i]}", fontweight="bold", fontsize=10)
    ax.grid(True, alpha=0.3)
axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
axes[-1].xaxis.set_major_locator(mdates.YearLocator())
plt.suptitle("TVP-VAR Net Pairwise Spillovers", fontweight="bold", y=1.01)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "04_TVP_VAR_NET.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 04_TVP_VAR_NET.png")

tvp_df = pd.DataFrame({"Date": tvp_dates, "TCI": TCI_tvp})
for i, lbl in enumerate(LABELS):
    tvp_df[f"TO_{lbl}"]   = TO_tvp[:, i]
    tvp_df[f"FROM_{lbl}"] = FROM_tvp[:, i]
    tvp_df[f"NET_{lbl}"]  = NET_tvp[:, i]
tvp_df.to_csv(os.path.join(OUTPUT_PATH, "04_TVP_VAR_results.csv"), index=False)
print("[SAVED] 04_TVP_VAR_results.csv")

print("\n" + "─" * 70)
print("  MODEL 4 — QVAR CONNECTEDNESS")
print("─" * 70)

def qvar_connectedness(Y_: np.ndarray, p: int, tau: float, H: int,
                        labels: list) -> dict:
    """
    Fit a Quantile VAR at quantile tau via equation-by-equation quantile
    regression, then compute GFEVD-style connectedness.
    """
    T_, n = Y_.shape

    Z = np.hstack([Y_[p - i - 1: T_ - i - 1] for i in range(p)] +
                  [np.ones((T_ - p, 1))])
    Y_dep = Y_[p:]

    coefs = np.zeros((n, Z.shape[1]))
    resid = np.zeros_like(Y_dep)

    for j in range(n):
        qr     = QuantReg(Y_dep[:, j], Z).fit(q=tau, max_iter=3000)
        coefs[j] = qr.params
        resid[:, j] = qr.resid

    A_list = [coefs[:, i * n:(i + 1) * n] for i in range(p)]
    Sigma  = np.cov(resid.T)

    try:
        G   = gfevd(A_list, Sigma, H)
        ct  = connectedness_table(G, labels)
    except Exception as e:
        print(f"    [WARN] tau={tau:.2f}: GFEVD failed ({e})")
        ct  = None
    return ct

qvar_results = {}
for tau in QUANTILES_QVAR:
    print(f"  Estimating QVAR at τ = {tau:.2f} …", end=" ")
    ct_q = qvar_connectedness(Y, VAR_LAGS, tau, FORECAST_H, LABELS)
    if ct_q:
        qvar_results[tau] = ct_q
        print(f"TCI = {ct_q['TCI']*100:.2f}%")
    else:
        print("skipped")

taus_ok  = sorted(qvar_results.keys())
tci_vals = [qvar_results[q]["TCI"] * 100 for q in taus_ok]

fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(taus_ok, tci_vals, "o-", color="darkorchid", linewidth=2, markersize=7)
ax.set_xlabel("Quantile (τ)")
ax.set_ylabel("Total Connectedness Index (%)")
ax.set_title("QVAR — Total Connectedness Across Quantiles", fontweight="bold")
ax.set_xticks(taus_ok)
ax.grid(True, alpha=0.3)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "05_QVAR_TCI_across_quantiles.png"),
            dpi=150)
plt.close()
print("[SAVED] 05_QVAR_TCI_across_quantiles.png")

for tau in [taus_ok[0], taus_ok[len(taus_ok) // 2], taus_ok[-1]]:
    ct_q = qvar_results[tau]
    plot_connectedness_table(
        ct_q,
        f"QVAR Connectedness at τ = {tau:.2f}  "
        f"(TCI = {ct_q['TCI']*100:.1f}%)",
        f"05_QVAR_heatmap_tau{int(tau*100):02d}.png")
    print(f"[SAVED] 05_QVAR_heatmap_tau{int(tau*100):02d}.png")

net_matrix = np.array([[qvar_results[q]["NET"][i] * 100
                         for q in taus_ok] for i in range(N)])

fig, ax = plt.subplots(figsize=(12, 5))
x     = np.arange(len(taus_ok))
width = 0.8 / N
for i in range(N):
    ax.bar(x + i * width, net_matrix[i], width, label=LABELS[i],
           color=COLORS[i], edgecolor="white", linewidth=0.5)
ax.axhline(0, color="k", linewidth=0.8)
ax.set_xticks(x + width * (N - 1) / 2)
ax.set_xticklabels([f"τ={q}" for q in taus_ok], fontsize=9)
ax.set_ylabel("Net Spillover (%)")
ax.set_title("QVAR — Net Spillovers Across Quantiles", fontweight="bold")
ax.legend(fontsize=8, ncol=3, framealpha=0.7)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "05_QVAR_NET_bars.png"), dpi=150)
plt.close()
print("[SAVED] 05_QVAR_NET_bars.png")

qvar_summary = pd.DataFrame({
    "tau": taus_ok,
    "TCI": tci_vals,
    **{f"TO_{LABELS[i]}":   [qvar_results[q]["TO"][i]   * 100 for q in taus_ok] for i in range(N)},
    **{f"FROM_{LABELS[i]}": [qvar_results[q]["FROM"][i] * 100 for q in taus_ok] for i in range(N)},
    **{f"NET_{LABELS[i]}":  [qvar_results[q]["NET"][i]  * 100 for q in taus_ok] for i in range(N)},
})
qvar_summary.to_csv(os.path.join(OUTPUT_PATH, "05_QVAR_summary.csv"), index=False)
print("[SAVED] 05_QVAR_summary.csv")

print("\n" + "─" * 70)
print("  MODEL 5 — QUANTILE-ON-QUANTILE (QQ) ANALYSIS")
print("─" * 70)

def cross_quantilogram(x: np.ndarray, y: np.ndarray,
                        tau1: float, tau2: float,
                        lag: int = 0) -> float:
    """
    Cross-quantilogram statistic between x and y at (tau1, tau2).
    ρ = corr(ψ_τ1(x_t), ψ_τ2(y_{t-lag}))
    where ψ_τ(u) = τ - I(u < q_τ).
    """
    q1 = np.quantile(x, tau1)
    q2 = np.quantile(y, tau2)
    if lag > 0:
        psi_x = tau1 - (x[lag:] < q1).astype(float)
        psi_y = tau2 - (y[:-lag] < q2).astype(float)
    else:
        psi_x = tau1 - (x < q1).astype(float)
        psi_y = tau2 - (y < q2).astype(float)
    denom = np.sqrt(np.mean(psi_x ** 2)) * np.sqrt(np.mean(psi_y ** 2))
    return np.mean(psi_x * psi_y) / denom if denom > 0 else 0.0

print(f"  Computing QQ matrices for {N*(N-1)//2} variable pairs …")

QQ_LAG = 1

qq_matrices = {}
for i in range(N):
    for j in range(N):
        if i == j:
            continue
        mat = np.zeros((len(QQ_TAU), len(QQ_TAU)))
        for ti, tau_i in enumerate(QQ_TAU):
            for tj, tau_j in enumerate(QQ_TAU):
                mat[ti, tj] = cross_quantilogram(Y[:, i], Y[:, j],
                                                  tau_i, tau_j, QQ_LAG)
        qq_matrices[(i, j)] = mat

tau_lbls = [f"{t:.1f}" for t in QQ_TAU]
n_pairs  = min(N * (N - 1), 20)

pair_list = [(i, j) for i in range(N) for j in range(N) if i != j][:n_pairs]
ncols_qq  = 3
nrows_qq  = int(np.ceil(len(pair_list) / ncols_qq))

fig, axes = plt.subplots(nrows_qq, ncols_qq,
                          figsize=(ncols_qq * 4.5, nrows_qq * 4))
axes_flat = axes.flatten()

for k, (i, j) in enumerate(pair_list):
    ax  = axes_flat[k]
    mat = qq_matrices[(i, j)]
    im  = ax.imshow(mat, cmap="RdYlBu_r", vmin=-1, vmax=1,
                    aspect="auto", origin="lower")
    ax.set_xticks(range(len(QQ_TAU))); ax.set_xticklabels(tau_lbls, fontsize=6, rotation=45)
    ax.set_yticks(range(len(QQ_TAU))); ax.set_yticklabels(tau_lbls, fontsize=6)
    ax.set_xlabel(f"τ({LABELS[j]})", fontsize=8)
    ax.set_ylabel(f"τ({LABELS[i]})", fontsize=8)
    ax.set_title(f"{LABELS[i]} → {LABELS[j]}", fontsize=9, fontweight="bold")
    plt.colorbar(im, ax=ax, fraction=0.04, pad=0.03)

for k in range(len(pair_list), len(axes_flat)):
    axes_flat[k].set_visible(False)

fig.suptitle(f"Quantile-on-Quantile Cross-Quantilogram (lag={QQ_LAG})",
             fontweight="bold", y=1.01)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "06_QQ_heatmaps.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 06_QQ_heatmaps.png")

avg_qq = np.zeros((N, N))
for i in range(N):
    for j in range(N):
        if i != j:
            avg_qq[i, j] = np.mean(np.abs(qq_matrices[(i, j)]))

fig, ax = plt.subplots(figsize=(8, 6))
sns.heatmap(pd.DataFrame(avg_qq, index=LABELS, columns=LABELS),
            annot=True, fmt=".3f", cmap="Oranges",
            ax=ax, linewidths=0.5, annot_kws={"size": 8})
ax.set_title("Mean |Cross-Quantilogram| — QQ Connectedness Summary",
             fontweight="bold")
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "06_QQ_summary_heatmap.png"), dpi=150)
plt.close()
print("[SAVED] 06_QQ_summary_heatmap.png")

print("\n" + "─" * 70)
print("  MODEL 6a — WAVELET COHERENCE")
print("─" * 70)

def cwt_coherence(x: np.ndarray, y: np.ndarray,
                   wavelet: str = "cmor1.5-1.0",
                   scales: np.ndarray = None,
                   dt: float = 1.0):
    """
    Compute wavelet coherence between x and y using CWT.
    Returns: periods, coherence (scales × time).
    """
    if scales is None:
        scales = np.logspace(0, np.log10(len(x) / 4), 50)

    xn = (x - x.mean()) / (x.std() + 1e-12)
    yn = (y - y.mean()) / (y.std() + 1e-12)

    CWx, _ = pywt.cwt(xn, scales, wavelet, sampling_period=dt)
    CWy, _ = pywt.cwt(yn, scales, wavelet, sampling_period=dt)

    def smooth(M, sigma=3):
        from scipy.ndimage import uniform_filter1d
        return uniform_filter1d(np.abs(M), size=sigma, axis=1)

    Sxx   = smooth(CWx * np.conj(CWx))
    Syy   = smooth(CWy * np.conj(CWy))
    Sxy   = smooth(CWx * np.conj(CWy))
    coh   = (np.abs(Sxy) ** 2) / (Sxx * Syy + 1e-20)
    freqs = pywt.scale2frequency(wavelet, scales, precision=10) / dt
    periods = 1.0 / (freqs + 1e-20)
    return periods, coh

SCALES_CWT = np.logspace(0, np.log10(T // 4), 60)

plot_pairs = [(i, j) for i in range(N) for j in range(i + 1, N)][:10]

fig_rows = int(np.ceil(len(plot_pairs) / 2))
fig, axes = plt.subplots(fig_rows, 2,
                          figsize=(14, 3.5 * fig_rows))
axes_flat = axes.flatten() if len(plot_pairs) > 1 else [axes]

cmap_coh = LinearSegmentedColormap.from_list("coh",
    ["#313695","#74add1","#ffffbf","#f46d43","#a50026"])

for k, (i, j) in enumerate(plot_pairs):
    print(f"  Wavelet coherence: {LABELS[i]} vs {LABELS[j]} …")
    periods, coh = cwt_coherence(Y[:, i], Y[:, j], WAVELET_NAME, SCALES_CWT)

    ax    = axes_flat[k]
    ext   = [0, T, np.log2(periods[-1]), np.log2(periods[0])]
    im    = ax.imshow(np.log2(coh + 1e-8), extent=ext,
                      cmap=cmap_coh, aspect="auto",
                      vmin=-8, vmax=0, origin="upper")

    date_ticks = np.linspace(0, T - 1, 6, dtype=int)
    ax.set_xticks(date_ticks)
    ax.set_xticklabels([str(dates[d].year) for d in date_ticks], fontsize=8)

    p_levels = [5, 10, 22, 66, 250]
    ax.set_yticks([np.log2(p) for p in p_levels if
                   np.log2(periods[-1]) <= np.log2(p) <= np.log2(periods[0])])
    ax.set_yticklabels([f"{p}d" for p in p_levels if
                        np.log2(periods[-1]) <= np.log2(p) <= np.log2(periods[0])],
                       fontsize=8)
    ax.set_title(f"Coherence: {LABELS[i]} vs {LABELS[j]}", fontsize=10,
                 fontweight="bold")
    ax.set_ylabel("Period (days)")
    plt.colorbar(im, ax=ax, fraction=0.03, label="log₂(Coherence)")

for k in range(len(plot_pairs), len(axes_flat)):
    axes_flat[k].set_visible(False)

plt.suptitle("Wavelet (Morlet) Coherence Analysis", fontweight="bold", y=1.01)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "07_wavelet_coherence.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 07_wavelet_coherence.png")

print("\n" + "─" * 70)
print("  MODEL 6b — WAVELET QUANTILE CORRELATION (DWT)")
print("─" * 70)

def dwt_quantile_corr(x: np.ndarray, y: np.ndarray,
                       wavelet: str = "db4", levels: int = 5,
                       taus: np.ndarray = np.array([0.25, 0.5, 0.75])) -> dict:
    """
    Wavelet quantile correlation:
    1. Decompose x and y via DWT into detail levels d1…dL.
    2. For each level and each quantile τ, compute Spearman rank correlation
       on {(d_x,t > Q_τ(d_x)) AND (d_y,t > Q_τ(d_y))}.
    """
    cA_x, *cD_x = pywt.wavedec(x, wavelet, level=levels)
    cA_y, *cD_y = pywt.wavedec(y, wavelet, level=levels)

    results = {}
    detail_names = [f"d{levels - i}" for i in range(levels)] + ["Approx"]
    coeffs_x = list(reversed(cD_x)) + [cA_x]
    coeffs_y = list(reversed(cD_y)) + [cA_y]

    for name, cx, cy in zip(detail_names, coeffs_x, coeffs_y):
        tau_corrs = {}
        for tau in taus:
            m = min(len(cx), len(cy))
            cx_ = cx[:m]; cy_ = cy[:m]

            mask = (cx_ > np.quantile(cx_, tau)) & (cy_ > np.quantile(cy_, tau))
            if mask.sum() > 5:
                rho, pval = stats.spearmanr(cx_[mask], cy_[mask])
            else:
                rho, pval = np.nan, np.nan
            tau_corrs[tau] = (rho, pval)
        results[name] = tau_corrs
    return results

WQC_TAUS = np.array([0.10, 0.25, 0.50, 0.75, 0.90])

wqc_all = {}
for i in range(N):
    for j in range(i + 1, N):
        print(f"  WQC: {LABELS[i]} vs {LABELS[j]} …")
        wqc_all[(i, j)] = dwt_quantile_corr(
            Y[:, i], Y[:, j], WAVELET_DWT, DWT_LEVELS, WQC_TAUS)

scale_names = [f"d{DWT_LEVELS - k}" for k in range(DWT_LEVELS)] + ["Approx"]
period_map  = {f"d{s}": 2**(s - 1) * 2 for s in range(1, DWT_LEVELS + 1)}
period_map["Approx"] = 2**DWT_LEVELS * 2

n_pairs_wqc = len(wqc_all)
ncols_w     = 3
nrows_w     = int(np.ceil(n_pairs_wqc / ncols_w))

fig, axes = plt.subplots(nrows_w, ncols_w,
                          figsize=(ncols_w * 5, nrows_w * 4))
axes_flat = axes.flatten() if n_pairs_wqc > 1 else [axes]

for k, ((i, j), res) in enumerate(wqc_all.items()):
    ax = axes_flat[k]
    for tau, color in zip(WQC_TAUS, ["#1a237e","#0288d1","#388e3c","#f57c00","#c62828"]):
        corrs = [res[s][tau][0] if not np.isnan(res[s][tau][0]) else 0
                 for s in scale_names]
        ax.plot(range(len(scale_names)), corrs, "o-", color=color,
                linewidth=1.5, markersize=5, label=f"τ={tau:.2f}")
    ax.axhline(0, color="k", linewidth=0.6, linestyle="--")
    ax.set_xticks(range(len(scale_names)))
    ax.set_xticklabels(scale_names, rotation=30, fontsize=7)
    ax.set_title(f"WQC: {LABELS[i]} vs {LABELS[j]}", fontsize=9, fontweight="bold")
    ax.set_ylabel("Spearman ρ")
    ax.set_ylim(-1.1, 1.1)
    ax.legend(fontsize=7, ncol=2, framealpha=0.6)
    ax.grid(True, alpha=0.3)

for k in range(n_pairs_wqc, len(axes_flat)):
    axes_flat[k].set_visible(False)

plt.suptitle(f"Wavelet Quantile Correlation (DWT: {WAVELET_DWT}, L={DWT_LEVELS})",
             fontweight="bold", y=1.01)
plt.tight_layout()
fig.savefig(os.path.join(OUTPUT_PATH, "08_wavelet_quantile_correlation.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 08_wavelet_quantile_correlation.png")

rows = []
for (i, j), res in wqc_all.items():
    for scale, tdict in res.items():
        for tau, (rho, pval) in tdict.items():
            rows.append({"Var1": LABELS[i], "Var2": LABELS[j],
                         "Scale": scale, "Tau": tau,
                         "Spearman_rho": rho, "p_value": pval})
pd.DataFrame(rows).to_csv(
    os.path.join(OUTPUT_PATH, "08_wavelet_quantile_corr.csv"), index=False)
print("[SAVED] 08_wavelet_quantile_corr.csv")

print("\n" + "─" * 70)
print("  GENERATING SUMMARY DASHBOARD")
print("─" * 70)

fig = plt.figure(figsize=(16, 10))
gs  = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.35)

ax1 = fig.add_subplot(gs[0, :])
ax1.plot(roll_dates, TCI_rolling, color="navy", linewidth=1.2,
         label=f"Rolling DY (win={ROLLING_WIN}d)")
ax1.plot(tvp_dates[valid], TCI_tvp[valid], color="darkred", linewidth=1.2,
         linestyle="--", label=f"TVP-VAR (λ={TVP_FORGETTING})")
ax1.set_ylabel("TCI (%)")
ax1.set_title("Dynamic Total Connectedness Index Comparison", fontweight="bold")
ax1.legend(fontsize=9)
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax1.xaxis.set_major_locator(mdates.YearLocator())
ax1.grid(True, alpha=0.3)

ax2 = fig.add_subplot(gs[1, 0])
ax2.plot(taus_ok, tci_vals, "o-", color="darkorchid", linewidth=2, markersize=8)
ax2.axhline(CT_static["TCI"] * 100, color="gray", linestyle="--", linewidth=1,
            label=f"Static DY ({CT_static['TCI']*100:.1f}%)")
ax2.set_xlabel("Quantile (τ)")
ax2.set_ylabel("TCI (%)")
ax2.set_title("QVAR: TCI Across Quantiles", fontweight="bold")
ax2.legend(fontsize=8)
ax2.set_xticks(taus_ok)
ax2.grid(True, alpha=0.3)

ax3 = fig.add_subplot(gs[1, 1])
net_vals = CT_static["NET"] * 100
colors_bar = ["seagreen" if v >= 0 else "tomato" for v in net_vals]
ax3.bar(LABELS, net_vals, color=colors_bar, edgecolor="white")
ax3.axhline(0, color="k", linewidth=0.8)
ax3.set_xticklabels(LABELS, rotation=40, ha="right", fontsize=9)
ax3.set_ylabel("Net Spillover (%)")
ax3.set_title("Static DY: Net Spillovers", fontweight="bold")
ax3.grid(True, alpha=0.3, axis="y")

fig.suptitle(
    "Connectedness Analysis — Summary Dashboard\n"
    f"Variables: {', '.join(LABELS)}  |  Period: "
    f"{dates[0].strftime('%b %Y')} – {dates[-1].strftime('%b %Y')}",
    fontweight="bold", fontsize=13)

fig.savefig(os.path.join(OUTPUT_PATH, "00_summary_dashboard.png"),
            dpi=150, bbox_inches="tight")
plt.close()
print("[SAVED] 00_summary_dashboard.png")

print("\n" + "=" * 70)
print("  ALL MODELS COMPLETE")
print(f"  Results saved to: {OUTPUT_PATH}")
print("=" * 70)
print("""
  Output files:
  ├── 00_summary_dashboard.png
  ├── 01_descriptive_stats.csv
  ├── 01_correlation_heatmap.png
  ├── 02_static_DY_table.csv
  ├── 02_static_DY_heatmap.png
  ├── 02_static_DY_bars.png
  ├── 03_rolling_TCI.png / .csv
  ├── 03_rolling_NET_spillovers.png
  ├── 04_TVP_VAR_TCI.png
  ├── 04_TVP_VAR_NET.png
  ├── 04_TVP_VAR_results.csv
  ├── 05_QVAR_TCI_across_quantiles.png
  ├── 05_QVAR_heatmap_tau*.png
  ├── 05_QVAR_NET_bars.png
  ├── 05_QVAR_summary.csv
  ├── 06_QQ_heatmaps.png
  ├── 06_QQ_summary_heatmap.png
  ├── 07_wavelet_coherence.png
  ├── 08_wavelet_quantile_correlation.png
  └── 08_wavelet_quantile_corr.csv
""")
