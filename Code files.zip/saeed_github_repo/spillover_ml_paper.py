"""
╔══════════════════════════════════════════════════════════════════╗
║  ML SPILLOVER PREDICTION — RNN / LSTM / GRU / KAN               ║
║  Replicates & extends Del Nero & Giudici (2025)                  ║
║  Finance Research Letters                                        ║
╠══════════════════════════════════════════════════════════════════╣
   DATASET PATH : <project>/Dataset
   OUTPUT PATH  : <project>/Results_ML_Paper
╠══════════════════════════════════════════════════════════════════╣
║  REQUIRED FILES:                                                 ║
║    Returns_Data.csv            (daily log-returns, 13 assets)    ║
║    GARCH11_Volatility_Data.csv (GARCH conditional volatility)    ║
║    RollingDY_Results.csv       (DY TCI + net spillovers)         ║
╠══════════════════════════════════════════════════════════════════╣
║  INSTALL: pip install pykan torch scikit-learn matplotlib        ║
║               seaborn shap numpy pandas openpyxl                 ║
║  RUN:     python spillover_ml_paper.py                           ║
╚══════════════════════════════════════════════════════════════════╝
"""

DATASET_DIR = Path(__file__).resolve().parent / "Dataset"
OUTPUT_DIR = Path(__file__).resolve().parent / "Results_ML_Paper"

TARGETS = ["TCI", "Net_AIQ", "Net_ROBT", "Net_ICLN"]

LAG        = 5
LEAD       = 1

TRAIN_FRAC = 0.60
VAL_FRAC   = 0.20

HIDDEN_DIM = 64
N_LAYERS   = 2
DROPOUT    = 0.2
EPOCHS     = 100
LR         = 1e-3
PATIENCE   = 15
BATCH_SIZE = 32

KAN_GRID   = 3
KAN_ORDER  = 3
KAN_LAMB   = 1e-2

SEED       = 42
DPI        = 180
FIG_FMT    = "png"

import os, sys, warnings, random, logging, copy
from pathlib import Path
from datetime import datetime

warnings.filterwarnings("ignore")

MISSING = []
for pkg, mod in [("numpy","numpy"),("pandas","pandas"),("torch","torch"),
                 ("matplotlib","matplotlib"),("sklearn","sklearn"),
                 ("kan","kan"),("shap","shap"),("scipy","scipy")]:
    try: __import__(mod)
    except ImportError: MISSING.append(pkg)

if MISSING:
    print(f"  pip install {' '.join(MISSING)}")
    sys.exit(1)

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import shap
from kan import KAN

Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(Path(OUTPUT_DIR)/"ML_run.log", mode="w", encoding="utf-8"),
    ]
)
log = logging.getLogger(__name__)

def out(name): return str(Path(OUTPUT_DIR)/name)
def savefig(name):
    p = out(f"{name}.{FIG_FMT}")
    plt.savefig(p, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close()
    log.info(f"  Saved {name}.{FIG_FMT}  ({Path(p).stat().st_size//1024} KB)")

log.info("="*65)
log.info("  ML SPILLOVER PAPER — Complete Production Run")
log.info(f"  Started  : {datetime.now():%Y-%m-%d %H:%M:%S}")
log.info(f"  Device   : {DEVICE.upper()}")
log.info("="*65)
log.info("\n  ── Loading data ──")

def req(f):
    p = Path(DATASET_DIR)/f
    if not p.exists():
        log.error(f"FILE NOT FOUND: {p}")
        sys.exit(1)
    return str(p)

ret = pd.read_csv(req("Returns_Data.csv"),
                  parse_dates=["Date"]).set_index("Date").sort_index()
gv  = pd.read_csv(req("GARCH11_Volatility_Data.csv"),
                  parse_dates=["Date"]).set_index("Date").sort_index()
dy  = pd.read_csv(req("RollingDY_Results.csv"),
                  parse_dates=["Date"]).set_index("Date").sort_index()

gv.columns = ["GARCH_"+c for c in gv.columns]

ASSETS     = list(ret.columns)
FEAT_COLS  = list(ret.columns) + list(gv.columns)

log.info(f"  Returns  : {ret.shape[0]} obs  assets={ASSETS}")
log.info(f"  GARCH    : {gv.shape[0]} obs")
log.info(f"  Rolling DY: {dy.shape[0]} obs  cols={list(dy.columns)}")
log.info(f"  Features : {len(FEAT_COLS)} total (returns + GARCH only — no leakage)")

log.info("\n  ── Building panel ──")

panel = ret.join(gv, how="left").join(dy, how="left").dropna()
log.info(f"  Panel: {panel.shape[0]} obs × {panel.shape[1]} cols")
log.info(f"  Date range: {panel.index[0].date()} → {panel.index[-1].date()}")

def build_supervised(df, feat_cols, targets, lag, lead):
    fd = df[feat_cols].values
    td = df[targets].values
    X_rows, y_rows = [], []
    for i in range(lag, len(df)-lead):
        X_rows.append(fd[i-lag:i].flatten())
        y_rows.append(td[i+lead])
    X     = np.array(X_rows, dtype=np.float32)
    y     = np.array(y_rows, dtype=np.float32)
    dates = df.index[lag:len(df)-lead]
    return X, y, dates

X_flat, y, dates = build_supervised(panel, FEAT_COLS, TARGETS, LAG, LEAD)
N_FEAT = X_flat.shape[1]
N      = len(X_flat)

log.info(f"  Supervised: X={X_flat.shape}  y={y.shape}")

def build_3d(df, feat_cols, targets, lag, lead):
    fd = df[feat_cols].values
    td = df[targets].values
    X3, y3 = [], []
    for i in range(lag, len(df)-lead):
        X3.append(fd[i-lag:i])
        y3.append(td[i+lead])
    dates3 = df.index[lag:len(df)-lead]
    return np.array(X3, dtype=np.float32), np.array(y3, dtype=np.float32), dates3

X_3d, y_3d, _ = build_3d(panel, FEAT_COLS, TARGETS, LAG, LEAD)
log.info(f"  3D tensor  : X_3d={X_3d.shape}  (for RNN/LSTM/GRU)")

train_end = int(N * TRAIN_FRAC)
val_end   = int(N * (TRAIN_FRAC + VAL_FRAC))

X_tr,  y_tr  = X_flat[:train_end],        y[:train_end]
X_va,  y_va  = X_flat[train_end:val_end], y[train_end:val_end]
X_te,  y_te  = X_flat[val_end:],          y[val_end:]

X3_tr = X_3d[:train_end];  X3_va = X_3d[train_end:val_end];  X3_te = X_3d[val_end:]

dates_te = dates[val_end:]

log.info(f"\n  Train: {len(X_tr):>4} obs ({dates[0].date()} → {dates[train_end-1].date()})")
log.info(f"  Val  : {len(X_va):>4} obs ({dates[train_end].date()} → {dates[val_end-1].date()})")
log.info(f"  Test : {len(X_te):>4} obs ({dates[val_end].date()} → {dates[-1].date()})")

sx = StandardScaler(); sy = StandardScaler()

X_tr_s  = sx.fit_transform(X_tr)
X_va_s  = sx.transform(X_va)
X_te_s  = sx.transform(X_te)
y_tr_s  = sy.fit_transform(y_tr)
y_va_s  = sy.transform(y_va)

sx3 = StandardScaler()
X3_tr_s = sx3.fit_transform(X3_tr.reshape(-1, len(FEAT_COLS))).reshape(X3_tr.shape)
X3_va_s = sx3.transform(X3_va.reshape(-1, len(FEAT_COLS))).reshape(X3_va.shape)
X3_te_s = sx3.transform(X3_te.reshape(-1, len(FEAT_COLS))).reshape(X3_te.shape)

def evaluate(y_true, y_pred, names=TARGETS):
    rows = []
    for i, n in enumerate(names):
        yt, yp = y_true[:,i], y_pred[:,i]
        rmse   = np.sqrt(mean_squared_error(yt, yp))
        mae    = mean_absolute_error(yt, yp)
        r2     = r2_score(yt, yp)
        rw     = np.sqrt(mean_squared_error(yt[1:], yt[:-1]))
        theil  = rmse / max(rw, 1e-9)
        da     = np.mean(np.sign(np.diff(yt)) == np.sign(np.diff(yp)))
        rows.append({"Target":n,"MAE":mae,"RMSE":rmse,
                     "R²":r2,"Theil_U":theil,"DirAcc":da})
    return pd.DataFrame(rows).set_index("Target")

class SpilloverDS(torch.utils.data.Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)
    def __len__(self): return len(self.X)
    def __getitem__(self, i): return self.X[i], self.y[i]

def make_loader(X, y, shuffle=True):
    return torch.utils.data.DataLoader(
        SpilloverDS(X,y), batch_size=BATCH_SIZE, shuffle=shuffle)

class RNNModel(nn.Module):
    def __init__(self, n_feat, hidden, n_layers, n_out, dropout, kind="RNN"):
        super().__init__()
        cls = {"RNN": nn.RNN, "LSTM": nn.LSTM, "GRU": nn.GRU}[kind]
        self.rnn  = cls(n_feat, hidden, n_layers, batch_first=True,
                        dropout=dropout if n_layers>1 else 0.0)
        self.drop = nn.Dropout(dropout)
        self.fc   = nn.Linear(hidden, n_out)
        self.kind = kind

    def forward(self, x):
        out, _ = self.rnn(x)
        out    = self.drop(out[:,-1])
        return self.fc(out)

def train_rnn(kind, X3_tr_s, y_tr_s, X3_va_s, y_va_s):
    """Train RNN/LSTM/GRU with early stopping. Returns model, losses."""
    log.info(f"\n  Training {kind} …")
    n_feat = X3_tr_s.shape[2]
    n_out  = y_tr_s.shape[1]
    model  = RNNModel(n_feat, HIDDEN_DIM, N_LAYERS, n_out, DROPOUT, kind).to(DEVICE)
    opt    = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=1e-5)
    sched  = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=5, factor=0.5)
    loss_fn = nn.MSELoss()

    tr_loader = make_loader(X3_tr_s, y_tr_s, shuffle=True)
    va_X = torch.tensor(X3_va_s, dtype=torch.float32).to(DEVICE)
    va_y = torch.tensor(y_va_s,  dtype=torch.float32).to(DEVICE)

    best_val, best_state, patience_cnt = float("inf"), None, 0
    train_losses, val_losses = [], []

    for epoch in range(EPOCHS):
        model.train()
        ep_loss = 0
        for xb, yb in tr_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            ep_loss += loss.item()

        model.eval()
        with torch.no_grad():
            vl = float(loss_fn(model(va_X), va_y))
        tl = ep_loss / len(tr_loader)
        train_losses.append(tl); val_losses.append(vl)
        sched.step(vl)

        if vl < best_val:
            best_val = vl
            best_state = copy.deepcopy(model.state_dict())
            patience_cnt = 0
        else:
            patience_cnt += 1

        if epoch % 20 == 0:
            log.info(f"    {kind} epoch {epoch+1:>3}  train={tl:.4f}  val={vl:.4f}")

        if patience_cnt >= PATIENCE:
            log.info(f"    Early stop at epoch {epoch+1}  best_val={best_val:.4f}")
            break

    model.load_state_dict(best_state)
    return model, train_losses, val_losses

def predict_rnn(model, X3_s):
    model.eval()
    with torch.no_grad():
        return model(torch.tensor(X3_s, dtype=torch.float32).to(DEVICE)).cpu().numpy()

log.info("\n" + "="*65)
log.info("  TRAINING ALL MODELS")
log.info("="*65)

all_losses = {}

rnn_model, rnn_tl, rnn_vl = train_rnn("RNN", X3_tr_s, y_tr_s, X3_va_s, y_va_s)
all_losses["RNN"] = (rnn_tl, rnn_vl)
pred_rnn_s = predict_rnn(rnn_model, X3_te_s)
pred_rnn   = sy.inverse_transform(pred_rnn_s)
m_rnn      = evaluate(y_te, pred_rnn)
log.info(f"  RNN Test:\n{m_rnn.round(4).to_string()}")

lstm_model, lstm_tl, lstm_vl = train_rnn("LSTM", X3_tr_s, y_tr_s, X3_va_s, y_va_s)
all_losses["LSTM"] = (lstm_tl, lstm_vl)
pred_lstm_s = predict_rnn(lstm_model, X3_te_s)
pred_lstm   = sy.inverse_transform(pred_lstm_s)
m_lstm      = evaluate(y_te, pred_lstm)
log.info(f"  LSTM Test:\n{m_lstm.round(4).to_string()}")

gru_model, gru_tl, gru_vl = train_rnn("GRU", X3_tr_s, y_tr_s, X3_va_s, y_va_s)
all_losses["GRU"] = (gru_tl, gru_vl)
pred_gru_s = predict_rnn(gru_model, X3_te_s)
pred_gru   = sy.inverse_transform(pred_gru_s)
m_gru      = evaluate(y_te, pred_gru)
log.info(f"  GRU Test:\n{m_gru.round(4).to_string()}")

log.info(f"\n  Training KAN …")
KAN_ARCH = [N_FEAT, max(N_FEAT//4, 16), len(TARGETS)]
log.info(f"  KAN arch: {KAN_ARCH}  grid={KAN_GRID}  k={KAN_ORDER}")

Xtr_t = torch.tensor(X_tr_s, dtype=torch.float32)
ytr_t = torch.tensor(y_tr_s, dtype=torch.float32)
Xva_t = torch.tensor(X_va_s, dtype=torch.float32)
yva_t = torch.tensor(y_va_s, dtype=torch.float32)
Xte_t = torch.tensor(X_te_s, dtype=torch.float32)

kan_dataset = {"train_input": Xtr_t, "train_label": ytr_t,
               "test_input" : Xva_t, "test_label"  : yva_t}

kan_model = KAN(width=KAN_ARCH, grid=KAN_GRID, k=KAN_ORDER,
                seed=SEED, device=DEVICE)

kan_opt  = torch.optim.Adam(kan_model.parameters(), lr=LR, weight_decay=KAN_LAMB)
kan_loss_fn = nn.MSELoss()
kan_best_val, kan_best_state, kan_patience = float("inf"), None, 0
kan_tl, kan_vl = [], []

for step in range(150):
    kan_model.train()
    kan_opt.zero_grad()
    pred_k = kan_model(Xtr_t)
    loss_k = kan_loss_fn(pred_k, ytr_t)
    l1_reg = sum(p.abs().mean() for lay in kan_model.act_fun
                 for p in lay.parameters() if p.requires_grad)
    (loss_k + KAN_LAMB * l1_reg).backward()
    kan_opt.step()

    kan_model.eval()
    with torch.no_grad():
        vl_k = float(kan_loss_fn(kan_model(Xva_t), yva_t))
    kan_tl.append(float(loss_k)); kan_vl.append(vl_k)

    if vl_k < kan_best_val:
        kan_best_val = vl_k
        kan_best_state = copy.deepcopy(kan_model.state_dict())
        kan_patience = 0
    else:
        kan_patience += 1

    if step % 30 == 0:
        log.info(f"    KAN step {step+1:>3}  train={float(loss_k):.4f}  val={vl_k:.4f}")

    if kan_patience >= PATIENCE:
        log.info(f"    KAN early stop at step {step+1}")
        break

kan_model.load_state_dict(kan_best_state)
all_losses["KAN"] = (kan_tl, kan_vl)

log.info("  KAN LBFGS fine-tuning …")
kan_model.fit(kan_dataset, opt="LBFGS", steps=30, lamb=KAN_LAMB,
              lamb_l1=1.0, lamb_entropy=2.0, log=30, metrics=None)

kan_model.eval()
with torch.no_grad():
    pred_kan_s = kan_model(Xte_t).numpy()
pred_kan = sy.inverse_transform(pred_kan_s)
m_kan    = evaluate(y_te, pred_kan)
log.info(f"  KAN Test:\n{m_kan.round(4).to_string()}")

log.info("\n" + "="*65)
log.info("  MODEL COMPARISON — Test Set")
log.info("="*65)

comp = pd.concat([
    m_rnn.add_prefix("RNN_"),
    m_lstm.add_prefix("LSTM_"),
    m_gru.add_prefix("GRU_"),
    m_kan.add_prefix("KAN_"),
], axis=1)
log.info("\n" + comp.round(4).to_string())

paper_table = pd.DataFrame(index=TARGETS)
for model_name, m in [("RNN",m_rnn),("LSTM",m_lstm),("GRU",m_gru),("KAN",m_kan)]:
    paper_table[f"{model_name}_RMSE"]   = m["RMSE"].round(4)
    paper_table[f"{model_name}_MAE"]    = m["MAE"].round(4)
    paper_table[f"{model_name}_TheilU"] = m["Theil_U"].round(4)
paper_table.to_csv(out("Table_ModelComparison.csv"))
log.info("\n  Paper table saved → Table_ModelComparison.csv")
log.info("\n" + paper_table.to_string())

log.info("\n  ── SHAP analysis ──")

flat_feat_names = [f"{c}[t-{l+1}]" for l in range(LAG) for c in FEAT_COLS]

def shap_for_rnn(model, X3_te_s, X3_tr_s, target_idx=0, n_bg=100):
    """Compute SHAP values for one target using KernelExplainer on flattened inputs."""

    Xte_flat = X3_te_s.reshape(len(X3_te_s), -1)
    Xbg_flat = X3_tr_s[:n_bg].reshape(n_bg, -1)

    def predict_flat(X_flat):
        X3 = X_flat.reshape(-1, LAG, len(FEAT_COLS))
        mdl = model.eval()
        with torch.no_grad():
            out = mdl(torch.tensor(X3, dtype=torch.float32).to(DEVICE))
        return out[:,target_idx].cpu().numpy()

    explainer = shap.KernelExplainer(predict_flat, Xbg_flat)
    shap_vals = explainer.shap_values(Xte_flat[:50], nsamples=100)
    return shap_vals, Xte_flat[:50]

log.info("  Computing SHAP for GRU (TCI target) …")
shap_gru, Xte_shap = shap_for_rnn(gru_model, X3_te_s, X3_tr_s, target_idx=0, n_bg=80)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("SHAP Feature Importance — GRU Model (TCI Target)\n"
             "Consistent with Del Nero & Giudici (2025) Fig. 16",
             fontsize=12, fontweight="bold")

shap_mean = np.abs(shap_gru).mean(axis=0)
shap_df   = pd.Series(shap_mean, index=flat_feat_names)
top20     = shap_df.nlargest(20)

axes[0].barh(top20.index, top20.values, color="#1F3864", edgecolor="white")
axes[0].set_xlabel("Mean |SHAP value|")
axes[0].set_title("Top 20 Features by SHAP Importance\n(GRU — TCI)")
axes[0].invert_yaxis()
axes[0].tick_params(axis="y", labelsize=7)

lag_imp = shap_mean.reshape(LAG, len(FEAT_COLS)).sum(axis=1)
lag_labs = [f"Lag {i+1}" for i in range(LAG)]
axes[1].bar(lag_labs, lag_imp, color=["#1F3864","#2E75B6","#5B9BD5","#9BB7D4","#C9D9EC"])
axes[1].set_xlabel("Lag (most recent = Lag 1)")
axes[1].set_ylabel("Total |SHAP|")
axes[1].set_title("Importance by Lag\n(Lag 1 should dominate — like paper)")
for i, v in enumerate(lag_imp):
    axes[1].text(i, v+0.001, f"{v:.3f}", ha="center", fontsize=8)

plt.tight_layout()
savefig("Fig_SHAP_GRU")

log.info("\n  ── Generating paper figures ──")

C = {"navy":"#1F3864","blue":"#2E75B6","orange":"#E86A2B",
     "green":"#5CB85C","red":"#C00000","gray":"#888888","light":"#9BB7D4"}

MODEL_COLORS  = {"RNN":"#888888","LSTM":"#2E75B6","GRU":"#5CB85C","KAN":"#C00000"}
MODEL_LS      = {"RNN":":", "LSTM":"--","GRU":"-.","KAN":"-"}
TARGET_COLORS = [C["navy"],C["blue"],C["orange"],C["green"]]

plt.rcParams.update({"font.family":"DejaVu Sans","axes.grid":True,
                     "grid.alpha":0.25,"axes.spines.top":False,
                     "axes.spines.right":False})

CRISIS = {
    "COVID-19":        ("2020-02-01","2020-07-01","#FDECEA"),
    "Energy Shock":    ("2022-01-01","2023-01-01","#EDE7F6"),
    "AI Rally":        ("2023-06-01","2024-09-01","#E8F5E9"),
}

def shade(ax, dates_arr):
    for lab,(s,e,col) in CRISIS.items():
        s_t,e_t = pd.Timestamp(s), pd.Timestamp(e)
        if s_t < dates_arr[-1] and e_t > dates_arr[0]:
            ax.axvspan(max(s_t,dates_arr[0]), min(e_t,dates_arr[-1]),
                       alpha=0.18, color=col, zorder=0)

fig, axes = plt.subplots(2, 2, figsize=(14, 9), sharex=False)
fig.suptitle("Training Convergence — All Four Models\n"
             "(Adam optimiser + early stopping)",
             fontsize=12, fontweight="bold")

for ax, (mname, (tl, vl)) in zip(axes.flatten(),
        [("RNN",(rnn_tl,rnn_vl)),("LSTM",(lstm_tl,lstm_vl)),
         ("GRU",(gru_tl,gru_vl)),("KAN",(kan_tl,kan_vl))]):
    ax.plot(tl, color=C["navy"],   lw=1.8, label="Train MSE")
    ax.plot(vl, color=C["orange"], lw=1.8, ls="--", label="Val MSE")
    best_ep = int(np.argmin(vl))
    ax.axvline(best_ep, color=C["red"], lw=1, ls=":", alpha=0.7)
    ax.set_title(f"{mname}  (best val step={best_ep+1})", fontsize=10)
    ax.set_xlabel("Training steps"); ax.set_ylabel("MSE loss")
    ax.legend(fontsize=8)
    ax.set_yscale("log")

plt.tight_layout()
savefig("Fig1_LossConvergence")

fig, axes = plt.subplots(4, 1, figsize=(14, 18), sharex=True)
fig.suptitle("Spillover Forecasts vs Actual Values — Test Period\n"
             "RNN / LSTM / GRU / KAN  |  1-Step-Ahead",
             fontsize=12, fontweight="bold")

target_labels = {
    "TCI"      : "Total Connectedness Index (%)",
    "Net_AIQ"  : "Net Spillover — AI ETF / AIQ (%)",
    "Net_ROBT" : "Net Spillover — Robotics / ROBT (%)",
    "Net_ICLN" : "Net Spillover — Clean Energy / ICLN (%)",
}

PREDS = {"RNN":pred_rnn,"LSTM":pred_lstm,"GRU":pred_gru,"KAN":pred_kan}

for i, (tgt, label) in enumerate(target_labels.items()):
    ax = axes[i]
    ax.plot(dates_te, y_te[:,i], color=TARGET_COLORS[i],
            lw=2.0, label="Actual", zorder=5)
    for mname, pred in PREDS.items():
        ax.plot(dates_te, pred[:,i],
                color=MODEL_COLORS[mname],
                ls=MODEL_LS[mname], lw=0.9,
                label=f"{mname}", alpha=0.85, zorder=4)
    shade(ax, dates_te)
    ax.set_ylabel(label, fontsize=8.5)
    rmse_str = "  ".join([f"{m}:{evaluate(y_te, p).loc[tgt,'RMSE']:.2f}"
                           for m,p in PREDS.items()])
    ax.set_title(f"{tgt}  |  RMSE: {rmse_str}", fontsize=8.5)
    ax.legend(fontsize=7.5, loc="upper right", ncol=5, framealpha=0.85)

axes[-1].set_xlabel("Date", fontsize=10)
plt.tight_layout()
savefig("Fig2_ForecastVsActual")

fig, axes = plt.subplots(len(TARGETS), 4, figsize=(18, 14), sharex=True)
fig.suptitle("Net Spillover Predictions — All Models × All Targets",
             fontsize=12, fontweight="bold")

for j, (mname, pred) in enumerate(PREDS.items()):
    for i, tgt in enumerate(TARGETS):
        ax = axes[i][j]
        ax.plot(dates_te, y_te[:,i], color=TARGET_COLORS[i], lw=1.5, label="Actual")
        ax.plot(dates_te, pred[:,i], color=MODEL_COLORS[mname], lw=1.0, ls="--", label=mname)
        shade(ax, dates_te)
        if i == 0: ax.set_title(mname, fontsize=11, fontweight="bold")
        if j == 0: ax.set_ylabel(tgt, fontsize=9)
        ax.tick_params(labelsize=7)

plt.tight_layout()
savefig("Fig3_NetSpilloversAllModels")

from matplotlib.patches import FancyArrowPatch
import matplotlib.patches as mpatches

metrics_to_plot = ["RMSE","MAE","Theil_U"]
fig, axes = plt.subplots(1, len(TARGETS), figsize=(16, 5), subplot_kw=dict(projection="polar"))
fig.suptitle("Model Performance Radar — RMSE | MAE | Theil's U\n"
             "(Smaller = Better — matches Del Nero & Giudici Fig. 13)",
             fontsize=11, fontweight="bold")

angles = np.linspace(0, 2*np.pi, len(metrics_to_plot), endpoint=False).tolist()
angles += angles[:1]

for ax, tgt in zip(axes, TARGETS):
    for mname, m_df in [("RNN",m_rnn),("LSTM",m_lstm),("GRU",m_gru),("KAN",m_kan)]:
        vals = [m_df.loc[tgt, met] for met in metrics_to_plot]

        nv = vals + [vals[0]]
        ax.plot(angles, nv, color=MODEL_COLORS[mname], lw=1.8, label=mname)
        ax.fill(angles, nv, color=MODEL_COLORS[mname], alpha=0.08)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics_to_plot, fontsize=8)
    ax.set_title(tgt, pad=12, fontsize=10, fontweight="bold")
    ax.tick_params(labelsize=7)

handles = [mpatches.Patch(color=MODEL_COLORS[m], label=m) for m in PREDS.keys()]
fig.legend(handles=handles, loc="lower center", ncol=4, fontsize=9,
           bbox_to_anchor=(0.5,-0.02))
plt.tight_layout()
savefig("Fig4_RadarPlot")

log.info("  Training GARCH-GRU hybrid …")

garch_cols = [c for c in panel.columns if c.startswith("GARCH_")]
ret_cols   = ASSETS
ret_panel  = panel[ret_cols].values
gv_panel   = panel[garch_cols].values
eps_panel  = ret_panel / (gv_panel + 1e-8)

ep_df = pd.DataFrame(eps_panel, index=panel.index,
                     columns=[f"eps_{c}" for c in ASSETS])

hybrid_cols = list(ep_df.columns) + list(ret.columns)
hybrid_panel = ep_df.join(ret.loc[ep_df.index], how="inner").join(
    dy, how="inner").dropna()

X3h, yh, dates_h = build_3d(hybrid_panel,
                              list(ep_df.columns)+list(ret.columns),
                              TARGETS, LAG, LEAD)
Nh = len(X3h)
th_end = int(Nh*TRAIN_FRAC); vh_end = int(Nh*(TRAIN_FRAC+VAL_FRAC))
X3h_tr_s, X3h_va_s, X3h_te_s = X3h[:th_end], X3h[th_end:vh_end], X3h[vh_end:]
yh_tr, yh_va, yh_te = yh[:th_end], yh[th_end:vh_end], yh[vh_end:]

sxh = StandardScaler(); syh = StandardScaler()
X3h_tr_s = sxh.fit_transform(X3h_tr_s.reshape(-1,X3h.shape[2])).reshape(X3h_tr_s.shape)
X3h_va_s = sxh.transform(X3h_va_s.reshape(-1,X3h.shape[2])).reshape(X3h_va_s.shape)
X3h_te_s = sxh.transform(X3h_te_s.reshape(-1,X3h.shape[2])).reshape(X3h_te_s.shape)
yh_tr_s  = syh.fit_transform(yh_tr)
yh_va_s  = syh.transform(yh_va)

hybrid_model, hgru_tl, hgru_vl = train_rnn(
    "GRU", X3h_tr_s, yh_tr_s, X3h_va_s, yh_va_s)

pred_hybrid_s = predict_rnn(hybrid_model, X3h_te_s)
pred_hybrid   = syh.inverse_transform(pred_hybrid_s)
m_hybrid      = evaluate(yh_te, pred_hybrid)

log.info(f"  GARCH-GRU Hybrid Test:\n{m_hybrid.round(4).to_string()}")

dates_h_te = dates_h[vh_end:]

fig, axes = plt.subplots(len(TARGETS), 1, figsize=(14, 14), sharex=True)
fig.suptitle("GARCH-GRU Hybrid Model — Spillover Predictions vs Actual\n"
             "(GARCH-filtered residuals as input — matches Del Nero & Giudici Fig. 17-18)",
             fontsize=11, fontweight="bold")

for i, (tgt, label) in enumerate(target_labels.items()):
    ax = axes[i]
    ax.plot(dates_h_te, yh_te[:,i], color=TARGET_COLORS[i], lw=1.8,
            label="Actual", zorder=5)
    ax.plot(dates_h_te, pred_hybrid[:,i], color=C["orange"], lw=1.0,
            ls="--", label="GARCH-GRU Predicted", zorder=4)
    shade(ax, dates_h_te)
    rmse_h = np.sqrt(mean_squared_error(yh_te[:,i], pred_hybrid[:,i]))
    mae_h  = mean_absolute_error(yh_te[:,i], pred_hybrid[:,i])
    ax.set_ylabel(label, fontsize=8.5)
    ax.set_title(f"{tgt}  |  RMSE={rmse_h:.4f}  MAE={mae_h:.4f}", fontsize=9)
    ax.legend(fontsize=8, loc="upper right")

axes[-1].set_xlabel("Date", fontsize=10)
plt.tight_layout()
savefig("Fig5_GARCHGRUHybrid")

static_dy = pd.read_csv(req("RollingDY_Results.csv"), parse_dates=["Date"])
static_dy = static_dy.set_index("Date").sort_index()

net_cols = [c for c in static_dy.columns if c.startswith("Net_")]

fig, ax = plt.subplots(figsize=(10, 8))
corr_mat = static_dy[["TCI"]+net_cols].corr()
mask = np.zeros_like(corr_mat); np.fill_diagonal(mask, 1)
sns.heatmap(corr_mat, annot=True, fmt=".2f", cmap="RdYlGn",
            center=0, ax=ax, linewidths=0.5,
            annot_kws={"size":9}, vmin=-1, vmax=1)
ax.set_title("Cross-Spillover Correlation Matrix\n"
             "(DY Framework — Full Sample 2019–2026)",
             fontsize=11, fontweight="bold")
ax.tick_params(axis="x", rotation=45, labelsize=9)
ax.tick_params(axis="y", rotation=0,  labelsize=9)
plt.tight_layout()
savefig("Fig6_CrossSpilloverHeatmap")

x_range = np.linspace(-3, 3, 200)
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
fig.suptitle("KAN Learned Spline Activations φ(x) — Top Input Features\n"
             "(Unique KAN contribution — MLPs use fixed activations like ReLU)",
             fontsize=11, fontweight="bold")

kan_model.eval()
Xte_g = torch.tensor(X_te_s, dtype=torch.float32, requires_grad=True)
out_g = kan_model(Xte_g)
grad  = torch.autograd.grad(out_g.sum(), Xte_g)[0]
imp   = grad.abs().mean(dim=0).detach().numpy()
top3  = np.argsort(imp)[-3:][::-1]

from scipy.ndimage import gaussian_filter1d
for pi, feat_idx in enumerate(top3):
    ax = axes[pi]
    try:
        with torch.no_grad():
            probe = torch.zeros(len(x_range), N_FEAT)
            probe[:, feat_idx] = torch.tensor(x_range, dtype=torch.float32)
            sp_y  = (kan_model(probe)[:,0].numpy()
                     - kan_model(torch.zeros(1,N_FEAT))[0,0].item())
        sp_sm = gaussian_filter1d(sp_y, sigma=3)
        feat_name = flat_feat_names[feat_idx] if feat_idx < len(flat_feat_names) else f"feat_{feat_idx}"
        ax.plot(x_range, sp_sm, color=C["navy"], lw=2.5)
        ax.axhline(0, color="#999", lw=0.8, ls="--")
        ax.axvline(0, color="#999", lw=0.8, ls="--")
        ax.fill_between(x_range, 0, sp_sm, where=(sp_sm>0), alpha=0.18, color=C["orange"])
        ax.fill_between(x_range, 0, sp_sm, where=(sp_sm<0), alpha=0.18, color=C["navy"])
        ax.set_title(f"Feature: {feat_name}\nImportance: {imp[feat_idx]:.4f}", fontsize=9)
        ax.set_xlabel("Standardised input x")
        ax.set_ylabel("φ(x) contribution to TCI")
    except Exception as e:
        ax.text(0.5,0.5,f"Not available\n{e}", ha="center", va="center",
                transform=ax.transAxes)
plt.tight_layout()
savefig("Fig7_KANSplineActivations")

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("Subsample Robustness: COVID-19 vs AI Rally Period\n"
             "(GRU model — matches Del Nero & Giudici Fig. 19)",
             fontsize=11, fontweight="bold")

periods = {
    "COVID-19 (2020-01 to 2020-12)": ("2020-01-01","2021-01-01"),
    "AI Rally (2023-06 to 2024-09)": ("2023-06-01","2024-09-01"),
}

for ax, (period_name, (ps, pe)) in zip(axes, periods.items()):
    mask = (dates_te >= pd.Timestamp(ps)) & (dates_te <= pd.Timestamp(pe))
    if mask.sum() < 10:
        ax.text(0.5, 0.5, f"Period not in test set\n({ps} to {pe})",
                ha="center", va="center", transform=ax.transAxes)
        ax.set_title(period_name); continue

    d_sub = dates_te[mask]
    for mname, pred in PREDS.items():
        p_sub = pred[mask, 0]
        y_sub = y_te[mask, 0]
        if mname == "KAN":
            ax.plot(d_sub, p_sub, color=MODEL_COLORS[mname],
                    ls=MODEL_LS[mname], lw=1.5, label=f"{mname}")
    ax.plot(d_sub, y_te[mask,0], color=C["navy"], lw=2, label="Actual")
    ax.set_title(f"{period_name}", fontsize=9)
    ax.set_xlabel("Date"); ax.set_ylabel("TCI (%)")
    ax.legend(fontsize=8)

plt.tight_layout()
savefig("Fig8_SubsampleCrisis")

log.info("\n  ── Saving outputs ──")

paper_table.to_csv(out("Table_ModelComparison.csv"))

hybrid_vs_gru = pd.DataFrame({
    "GRU_RMSE"   : m_gru["RMSE"],
    "Hybrid_RMSE": m_hybrid["RMSE"],
    "GRU_MAE"    : m_gru["MAE"],
    "Hybrid_MAE" : m_hybrid["MAE"],
}).round(5)
hybrid_vs_gru.to_csv(out("Table_GARCHGRUHybrid.csv"))
log.info("  Saved Table_GARCHGRUHybrid.csv")

pred_df = pd.DataFrame(index=dates_te)
for i, t in enumerate(TARGETS):
    pred_df[f"Actual_{t}"] = y_te[:,i]
    for mname, pred in PREDS.items():
        pred_df[f"{mname}_{t}"] = pred[:,i]
pred_df.to_csv(out("All_Predictions.csv"))
log.info("  Saved All_Predictions.csv")

shap_df.sort_values(ascending=False).to_csv(out("SHAP_GRU_TCI.csv"), header=["SHAP_importance"])
log.info("  Saved SHAP_GRU_TCI.csv")

log.info("\n" + "="*65)
log.info("  FINAL SUMMARY")
log.info("="*65)

log.info(f"""
  Models     : RNN | LSTM | GRU | KAN | GARCH-GRU Hybrid
  Features   : {len(FEAT_COLS)} (returns + GARCH vols — no leakage)
  Lag window : {LAG} days
  Dataset    : {N} samples ({dates[0].date()} → {dates[-1].date()})
  Split      : {int(TRAIN_FRAC*100)}/{int(VAL_FRAC*100)}/20 train/val/test
""")

log.info("  Test-set RMSE comparison:")
log.info(f"  {'Target':<15} {'RNN':>8} {'LSTM':>8} {'GRU':>8} {'KAN':>8}  BEST")
log.info(f"  {'-'*55}")
for t in TARGETS:
    model_metrics = {"rnn":m_rnn,"lstm":m_lstm,"gru":m_gru,"kan":m_kan}
    rmses = {m: model_metrics[m].loc[t,"RMSE"] for m in ["rnn","lstm","gru","kan"]}
    best = min(rmses, key=rmses.get).upper()
    log.info(f"  {t:<15} {rmses['rnn']:>8.3f} {rmses['lstm']:>8.3f} "
             f"{rmses['gru']:>8.3f} {rmses['kan']:>8.3f}  {best}")

log.info(f"\n  Output folder: {OUTPUT_DIR}")
log.info(f"  Completed    : {datetime.now():%Y-%m-%d %H:%M:%S}")
log.info("="*65)
log.info("  DONE.")